/* Pièces jointes locales : IndexedDB, données encodées dans la sauvegarde JSON. */
var NoteMedia = (function(){
  var dbPromise;
  var MAX = 8 * 1024 * 1024, TOTAL = 48 * 1024 * 1024;
  function db(){
    if(!dbPromise) dbPromise = new Promise(function(resolve,reject){
      var r=indexedDB.open('agenda.media.v1',1);
      r.onupgradeneeded=function(){r.result.createObjectStore('files');};
      r.onsuccess=function(){resolve(r.result);}; r.onerror=function(){reject(r.error);};
    }).catch(function(e){dbPromise=null;throw e;}); return dbPromise;
  }
  function tx(mode,fn){return db().then(function(d){return new Promise(function(resolve,reject){
    var t=d.transaction('files',mode), result; t.oncomplete=function(){resolve(result);};t.onerror=t.onabort=function(){reject(t.error||Error('Stockage indisponible'));};
    try { fn(t.objectStore('files'),function(v){result=v;}); }catch(e){t.abort();reject(e);}
  });});}
  function valid(v){return typeof v==='string' && v.length<=MAX*1.4 && /^data:(?:image\/(?:jpeg|png|webp)|audio\/(?:mp4|mpeg|aac|wav|x-wav|ogg|webm|3gpp|m4a|x-m4a|amr))(?:;codecs=[a-zA-Z0-9.,_-]+)?;base64,[A-Za-z0-9+/=]+$/.test(v);}
  function put(id,data){if(!valid(data))return Promise.reject(Error('Format ou taille non pris en charge'));return tx('readwrite',function(s){s.put(data,id);});}
  function get(id){return tx('readonly',function(s,set){var r=s.get(id);r.onsuccess=function(){set(r.result);};});}
  function remove(id){return tx('readwrite',function(s){s.delete(id);});}
  function read(file){return new Promise(function(resolve,reject){if(file.size>MAX){reject(Error('Fichier trop volumineux (8 Mo maximum)'));return;}var r=new FileReader();r.onload=function(){resolve(r.result);};r.onerror=function(){reject(Error('Lecture impossible'));};r.readAsDataURL(file);});}
  function photo(file){return read(file).then(function(data){return new Promise(function(resolve,reject){var img=new Image();img.onload=function(){try{var f=Math.min(1,1600/Math.max(img.width,img.height)), c=document.createElement('canvas');c.width=Math.max(1,Math.round(img.width*f));c.height=Math.max(1,Math.round(img.height*f));c.getContext('2d').drawImage(img,0,0,c.width,c.height);resolve(c.toDataURL('image/jpeg',.82));}catch(e){reject(e);}};img.onerror=function(){reject(Error('Photo illisible'));};img.src=data;});});}
  return {put:put,get:get,remove:remove,read:read,photo:photo,valid:valid,MAX:MAX,TOTAL:TOTAL};
})();
