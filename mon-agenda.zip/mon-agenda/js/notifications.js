/* Gestion des rappels par notification.
   - En APK Capacitor : utilise le plugin natif @capacitor/local-notifications,
     ce qui permet des rappels planifiés FIABLES même application fermée.
   - Sur le web (PWA / navigateur) : utilise l'API Notification ; les rappels se
     déclenchent tant que l'application est ouverte ou récemment active. */
var Reminders = (function () {

  // --- Détection de l'environnement natif Capacitor ---
  var Cap = (typeof window !== 'undefined') ? window.Capacitor : null;
  var isNativePlatform = !!(Cap && typeof Cap.isNativePlatform === 'function' && Cap.isNativePlatform());
  var LN = (isNativePlatform && Cap.Plugins && Cap.Plugins.LocalNotifications)
    ? Cap.Plugins.LocalNotifications : null;
  var native = !!LN;

  var timers = {};    // (web) id de tâche -> identifiant setTimeout
  var nativeIds = {}; // (natif) id de tâche -> id numérique de notification

  function isNative() { return native; }

  // --- Utilitaires ---
  function hashId(str) {
    var h = 0;
    str = String(str);
    for (var i = 0; i < str.length; i++) { h = ((h << 5) - h + str.charCodeAt(i)) | 0; }
    return (Math.abs(h) % 2147483600) + 1; // entier positif non nul (limite Android)
  }

  // --- Web : disponibilité / permission ---
  function supported() {
    return typeof window !== 'undefined' && 'Notification' in window;
  }
  function permission() {
    if (native) return 'granted';
    return supported() ? Notification.permission : 'denied';
  }

  function ensurePermission() {
    if (native) {
      return LN.requestPermissions()
        .then(function (res) { return (res && res.display) ? res.display : 'granted'; })
        .catch(function () { return 'denied'; });
    }
    if (!supported()) return Promise.resolve('denied');
    if (Notification.permission === 'default') {
      try {
        return Notification.requestPermission().catch(function () { return Notification.permission; });
      } catch (e) {
        return Promise.resolve(Notification.permission);
      }
    }
    return Promise.resolve(Notification.permission);
  }

  // --- Affichage immédiat (utilisé par le repli web) ---
  function show(title, body) {
    if (native) {
      // Notification immédiate native (rarement utilisée : l'OS gère les rappels planifiés)
      LN.schedule({ notifications: [{
        id: hashId('now-' + Date.now()),
        title: title || 'Rappel',
        body: body || ''
      }]}).catch(function () { /* ignoré */ });
      return;
    }
    if (permission() !== 'granted') return;
    var opts = {
      body: body || '',
      icon: 'assets/icons/icon-192.png',
      badge: 'assets/icons/icon-192.png',
      tag: title
    };
    if ('serviceWorker' in navigator && navigator.serviceWorker.ready) {
      navigator.serviceWorker.ready
        .then(function (reg) {
          if (reg && reg.showNotification) reg.showNotification(title, opts);
          else fallback(title, opts);
        })
        .catch(function () { fallback(title, opts); });
    } else {
      fallback(title, opts);
    }
  }

  function fallback(title, opts) {
    try { new Notification(title, opts); } catch (e) { /* ignoré */ }
  }

  // --- Planification d'un rappel ---
  // Web : programme un setTimeout (tâches ≤ 24 h, pendant que l'app est ouverte).
  // Natif : planifie une notification au niveau du système (même app fermée).
  function schedule(taskId, fireAtMs, title, body, callback) {
    clear(taskId);
    var delay = fireAtMs - Date.now();
    if (delay <= 0) return; // on ne planifie pas un rappel déjà passé

    if (native) {
      var id = hashId(taskId);
      nativeIds[taskId] = id;
      LN.schedule({ notifications: [{
        id: id,
        title: title || 'Rappel',
        body: body || '',
        schedule: { at: new Date(fireAtMs), allowWhileIdle: true },
        extra: { taskId: String(taskId) }
      }]}).catch(function () { /* ignoré */ });
      return;
    }

    if (delay > 24 * 60 * 60 * 1000) return; // web : au-delà de 24 h, géré par la vérif périodique
    timers[taskId] = window.setTimeout(function () {
      delete timers[taskId];
      if (typeof callback === 'function') callback();
    }, delay);
  }

  function clear(taskId) {
    if (native) {
      var id = nativeIds[taskId] || hashId(taskId);
      delete nativeIds[taskId];
      LN.cancel({ notifications: [{ id: id }] }).catch(function () { /* ignoré */ });
      return;
    }
    if (timers[taskId]) {
      window.clearTimeout(timers[taskId]);
      delete timers[taskId];
    }
  }

  function clearAll() {
    if (native) {
      nativeIds = {};
      if (LN.getPending) {
        LN.getPending().then(function (res) {
          var list = (res && res.notifications) || [];
          if (list.length) {
            LN.cancel({ notifications: list.map(function (n) { return { id: n.id }; }) })
              .catch(function () { /* ignoré */ });
          }
        }).catch(function () { /* ignoré */ });
      }
      return;
    }
    Object.keys(timers).forEach(function (id) { window.clearTimeout(timers[id]); });
    timers = {};
  }

  return {
    isNative: isNative,
    supported: supported,
    permission: permission,
    ensurePermission: ensurePermission,
    show: show,
    schedule: schedule,
    clear: clear,
    clearAll: clearAll
  };
})();
