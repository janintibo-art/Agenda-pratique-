/* =========================================================
   Mon Agenda — application
   ========================================================= */
(function () {
  'use strict';

  // ----- État -----
  var tasks = Storage.load();
  var filter = 'all';            // all | active | done
  var editingId = null;
  var currentPrio = 'normal';
  var currentCat = '';           // catégorie en cours d'édition dans la feuille
  var catFilter = '';            // filtre par catégorie ('' = toutes)
  var searchQuery = '';          // texte de recherche dans les tâches
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var deferredInstall = null;
  var swReg = null;              // enregistrement du service worker (mises à jour)

  // Catégories prédéfinies (couleur distincte, accordée à la palette)
  var CATEGORIES = [
    { id: 'travail', label: 'Travail', color: '#4F86C6' },
    { id: 'perso',   label: 'Perso',   color: '#C76B98' },
    { id: 'sante',   label: 'Santé',   color: '#3FA08C' },
    { id: 'maison',  label: 'Maison',  color: '#D08A4E' },
    { id: 'famille', label: 'Famille', color: '#8A78C4' },
    { id: 'loisirs', label: 'Loisirs', color: '#6FA15A' }
  ];
  function catById(id) {
    for (var i = 0; i < CATEGORIES.length; i++) if (CATEGORIES[i].id === id) return CATEGORIES[i];
    return null;
  }

  var view = 'tasks';            // tasks | calendar | notes
  var notes = Storage.loadNotes();
  var selectedDate = null;       // 'AAAA-MM-JJ' du jour affiché dans le bloc-notes
  var noteSaveTimer = null;

  var settings = Storage.loadSettings();
  var calMonth = null;           // Date du 1er du mois affiché dans le calendrier
  var calSelected = null;        // 'AAAA-MM-JJ' du jour sélectionné dans le calendrier

  // ----- Références DOM -----
  var $ = function (id) { return document.getElementById(id); };
  var heroDate = $('heroDate');
  var heroSummary = $('heroSummary');
  var listEl = $('list');
  var emptyEl = $('empty');
  var emptyTitle = $('emptyTitle');
  var emptyText = $('emptyText');
  var toastEl = $('toast');

  var quickInput = $('quickInput');
  var sheet = $('sheet');
  var backdrop = $('backdrop');
  var sheetTitle = $('sheetTitle');
  var fTitle = $('fTitle');
  var fNote = $('fNote');
  var fDate = $('fDate');
  var fTime = $('fTime');
  var sheetDelete = $('sheetDelete');

  // Vue Notes
  var viewTasks = $('viewTasks');
  var viewNotes = $('viewNotes');
  var fabEl = $('fab');
  var noteTextEl = $('noteText');
  var noteStatusEl = $('noteStatus');
  var dayLabelEl = $('dayLabelEl');
  var daySubEl = $('daySubEl');
  var dayInput = $('dayInput');
  var noteHistory = $('noteHistory');

  // Calendrier + réglages + champs supplémentaires
  var viewCalendar = $('viewCalendar');
  var calGrid = $('calGrid');
  var monthLabel = $('monthLabel');
  var calDetail = $('calDetail');
  var settingsSheet = $('settingsSheet');
  var fLead = $('fLead');
  var fRepeat = $('fRepeat');
  var bgLayer = $('bgLayer');
  var bgGrid = $('bgGrid');

  // Recherche, filtres par catégorie, mise à jour
  var searchBtn = $('searchBtn');
  var searchBar = $('searchBar');
  var searchInput = $('searchInput');
  var searchClear = $('searchClear');
  var catFilters = $('catFilters');
  var catPicker = $('catPicker');
  var updateBar = $('updateBar');

  // ===== Utilitaires date =====
  function pad(n) { return n < 10 ? '0' + n : '' + n; }

  function localDateStr(d) {
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }

  function dueAtMs(t) {
    if (!t.date) return null;
    var time = t.time || '09:00';
    var ms = new Date(t.date + 'T' + time + ':00').getTime();
    return isNaN(ms) ? null : ms;
  }

  function endOfDayMs(dateStr) {
    return new Date(dateStr + 'T23:59:59').getTime();
  }

  function isOverdue(t) {
    if (t.done || !t.date) return false;
    var now = Date.now();
    return t.time ? (dueAtMs(t) < now) : (endOfDayMs(t.date) < now);
  }

  function dayLabel(dateStr) {
    var today = new Date();
    var t0 = new Date(localDateStr(today) + 'T00:00:00');
    var d = new Date(dateStr + 'T00:00:00');
    var diff = Math.round((d - t0) / 86400000);
    if (diff === 0) return "Aujourd'hui";
    if (diff === 1) return 'Demain';
    if (diff === -1) return 'Hier';
    var opts = { day: 'numeric', month: 'long' };
    if (d.getFullYear() !== today.getFullYear()) opts.year = 'numeric';
    return d.toLocaleDateString('fr-FR', opts);
  }

  function capitalize(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }

  // ===== Rendu de l'en-tête =====
  function renderHeroDate() {
    var now = new Date();
    heroDate.textContent = capitalize(
      now.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' })
    );
  }

  function renderHero() {
    renderHeroDate();
    setHeroSummaryTasks();
  }

  function setHeroSummaryTasks() {
    var active = tasks.filter(function (t) { return !t.done; });
    var late = active.filter(isOverdue).length;

    if (active.length === 0) {
      heroSummary.innerHTML = tasks.length
        ? 'Tout est fait. Belle journée !'
        : 'Aucune tâche pour l’instant.';
      return;
    }
    var noun = active.length > 1 ? 'tâches' : 'tâche';
    var html = '<b>' + active.length + '</b> ' + noun + ' à faire';
    if (late > 0) html += ' · <span class="is-late">' + late + ' en retard</span>';
    heroSummary.innerHTML = html;
  }

  // ===== Construction d'une carte =====
  var ICON_CLOCK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2" stroke-linecap="round"/></svg>';
  var ICON_CHECK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M5 12l4 4 10-10" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  var ICON_REPEAT = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 9a7 7 0 0 1 12-3l2 2M20 15a7 7 0 0 1-12 3l-2-2" stroke-linecap="round" stroke-linejoin="round"/><path d="M18 4v4h-4M6 20v-4h4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  var ICON_BELL = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" stroke-linecap="round" stroke-linejoin="round"/><path d="M13.7 21a2 2 0 0 1-3.4 0" stroke-linecap="round"/></svg>';

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function chipFor(t) {
    if (!t.date) return '';
    var late = isOverdue(t);
    var label = dayLabel(t.date);
    if (t.time) label += ' · ' + t.time;
    return '<span class="chip' + (late ? ' chip--late' : '') + '">' +
      ICON_CLOCK + escapeHtml(label) + '</span>';
  }

  function prioFor(t) {
    if (t.prio === 'high') return '<span class="prio prio--high"><span class="prio__dot"></span>Haute</span>';
    if (t.prio === 'normal') return '<span class="prio prio--normal"><span class="prio__dot"></span>Moyenne</span>';
    return '';
  }

  function repeatChipFor(t) {
    if (!t.repeat || t.repeat === 'none') return '';
    var label = t.repeat === 'daily' ? 'Chaque jour'
              : t.repeat === 'weekly' ? 'Chaque sem.' : 'Chaque mois';
    return '<span class="chip">' + ICON_REPEAT + escapeHtml(label) + '</span>';
  }

  function leadChipFor(t) {
    if (!t.date || !t.lead) return '';
    var m = t.lead, label;
    if (m >= 1440) label = (m / 1440) + ' j avant';
    else if (m >= 60) label = (m / 60) + ' h avant';
    else label = m + ' min avant';
    return '<span class="chip">' + ICON_BELL + escapeHtml(label) + '</span>';
  }

  function catChipFor(t) {
    var c = catById(t.cat);
    if (!c) return '';
    return '<span class="catchip" style="--cc:' + c.color + '">' +
      '<span class="catchip__dot"></span>' + escapeHtml(c.label) + '</span>';
  }

  // Recherche insensible aux accents et à la casse
  function normTxt(s) {
    return (s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  }
  function taskMatches(t, q) {
    return normTxt(t.title).indexOf(q) >= 0 || normTxt(t.note).indexOf(q) >= 0;
  }

  function taskHtml(t) {
    var meta = chipFor(t) + catChipFor(t) + leadChipFor(t) + repeatChipFor(t) + prioFor(t);
    return '' +
      '<article class="task' + (t.done ? ' done' : '') + (isOverdue(t) ? ' task--late' : '') +
        '" data-id="' + t.id + '">' +
        '<button class="check" type="button" data-act="toggle" aria-label="' +
          (t.done ? 'Marquer à faire' : 'Marquer terminé') + '">' + ICON_CHECK + '</button>' +
        '<div class="task__body">' +
          '<p class="task__title">' + escapeHtml(t.title) + '</p>' +
          (t.note ? '<p class="task__note">' + escapeHtml(t.note) + '</p>' : '') +
          (meta ? '<div class="task__meta">' + meta + '</div>' : '') +
        '</div>' +
      '</article>';
  }

  // ===== Regroupement + rendu de la liste =====
  function sectionHtml(title, items, extraClass) {
    if (!items.length) return '';
    var cards = items.map(taskHtml).join('');
    return '<section class="section ' + (extraClass || '') + '">' +
      '<div class="section__head"><h2 class="section__title">' + title + '</h2>' +
      '<span class="section__count">' + items.length + '</span></div>' +
      cards + '</section>';
  }

  function byDueAsc(a, b) { return (dueAtMs(a) || 0) - (dueAtMs(b) || 0); }
  function byCreatedDesc(a, b) { return (b.createdAt || 0) - (a.createdAt || 0); }
  function byDoneDesc(a, b) { return (b.completedAt || b.createdAt || 0) - (a.completedAt || a.createdAt || 0); }

  function render() {
    renderHero();
    renderCatFilters();

    var todayStr = localDateStr(new Date());
    var q = normTxt(searchQuery.trim());
    var pool = tasks.filter(function (t) {
      if (filter === 'active' && t.done) return false;
      if (filter === 'done' && !t.done) return false;
      if (catFilter && (t.cat || '') !== catFilter) return false;
      if (q && !taskMatches(t, q)) return false;
      return true;
    });

    var late = [], today = [], upcoming = [], noDate = [], done = [];
    pool.forEach(function (t) {
      if (t.done) { done.push(t); return; }
      if (!t.date) { noDate.push(t); return; }
      if (isOverdue(t)) { late.push(t); return; }
      if (t.date === todayStr) { today.push(t); return; }
      upcoming.push(t);
    });

    late.sort(byDueAsc); today.sort(byDueAsc); upcoming.sort(byDueAsc);
    noDate.sort(byCreatedDesc); done.sort(byDoneDesc);

    var html = '';
    if (filter !== 'done') {
      html += sectionHtml('En retard', late, 'section--late');
      html += sectionHtml("Aujourd'hui", today);
      html += sectionHtml('À venir', upcoming);
      html += sectionHtml('Sans échéance', noDate);
    }
    if (filter !== 'active') {
      html += sectionHtml('Terminé', done);
    }

    listEl.innerHTML = html;

    if (html === '') {
      emptyEl.hidden = false;
      if (q || catFilter) {
        emptyTitle.textContent = 'Aucun résultat';
        emptyText.textContent = 'Aucune tâche ne correspond à votre recherche ou à ce filtre.';
      } else if (tasks.length === 0) {
        emptyTitle.textContent = 'Rien de prévu';
        emptyText.textContent = 'Commencez par ajouter votre première tâche ci-dessus.';
      } else if (filter === 'done') {
        emptyTitle.textContent = 'Aucune tâche terminée';
        emptyText.textContent = 'Les tâches cochées apparaîtront ici.';
      } else {
        emptyTitle.textContent = 'Tout est fait';
        emptyText.textContent = 'Aucune tâche en attente. Profitez-en !';
      }
    } else {
      emptyEl.hidden = true;
    }
  }

  // ===== Création / modification =====
  function makeTask(fields) {
    return {
      id: Storage.uid(),
      title: fields.title,
      note: fields.note || '',
      date: fields.date || '',
      time: fields.time || '',
      prio: fields.prio || 'normal',
      cat: fields.cat || '',
      lead: fields.lead || 0,
      repeat: fields.repeat || 'none',
      done: false,
      createdAt: Date.now(),
      completedAt: null,
      notified: false
    };
  }

  function persist() { Storage.saveAll(tasks); }

  function findTask(id) {
    for (var i = 0; i < tasks.length; i++) if (tasks[i].id === id) return tasks[i];
    return null;
  }

  function quickAdd() {
    var title = quickInput.value.trim();
    if (!title) { quickInput.focus(); return; }
    tasks.push(makeTask({ title: title }));
    persist();
    quickInput.value = '';
    render();
  }

  function toggleDone(id) {
    var t = findTask(id);
    if (!t) return;
    if (!t.done) {
      var finish = function () {
        t.done = true;
        t.completedAt = Date.now();
        Reminders.clear(t.id);
        spawnNextOccurrence(t);
        persist();
        renderCurrent();
      };
      var scope = (view === 'calendar') ? calDetail : listEl;
      var el = scope.querySelector('.task[data-id="' + id + '"]');
      if (reduceMotion || !el) { finish(); return; }
      el.classList.add('is-completing');
      window.setTimeout(finish, 220);
    } else {
      t.done = false;
      t.completedAt = null;
      t.notified = false;
      persist();
      scheduleOne(t);
      renderCurrent();
    }
  }

  function spawnNextOccurrence(t) {
    if (!t.repeat || t.repeat === 'none' || !t.date) return;
    var next = makeTask({
      title: t.title, note: t.note, date: advanceDate(t.date, t.repeat),
      time: t.time, prio: t.prio, cat: t.cat, lead: t.lead, repeat: t.repeat
    });
    tasks.push(next);
    scheduleOne(next);
  }

  function advanceDate(dateStr, repeat) {
    var d = new Date(dateStr + 'T00:00:00');
    if (repeat === 'daily') {
      d.setDate(d.getDate() + 1);
    } else if (repeat === 'weekly') {
      d.setDate(d.getDate() + 7);
    } else if (repeat === 'monthly') {
      var day = d.getDate();
      d.setDate(1);
      d.setMonth(d.getMonth() + 1);
      var lastDay = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
      d.setDate(Math.min(day, lastDay));
    }
    return localDateStr(d);
  }

  // ===== Feuille d'édition =====
  function setPrio(value) {
    currentPrio = value;
    var btns = sheet.querySelectorAll('.seg__btn');
    for (var i = 0; i < btns.length; i++) {
      var on = btns[i].getAttribute('data-prio') === value;
      btns[i].classList.toggle('is-active', on);
      btns[i].setAttribute('aria-checked', on ? 'true' : 'false');
    }
  }

  function setCat(value) {
    currentCat = value || '';
    if (!catPicker) return;
    var btns = catPicker.querySelectorAll('.catpill');
    for (var i = 0; i < btns.length; i++) {
      var on = (btns[i].getAttribute('data-cat') || '') === currentCat;
      btns[i].classList.toggle('is-active', on);
      btns[i].setAttribute('aria-checked', on ? 'true' : 'false');
    }
  }

  // Barre de filtres par catégorie (affichée seulement si des catégories sont utilisées)
  function renderCatFilters() {
    if (!catFilters) return;
    var used = {};
    tasks.forEach(function (t) { if (t.cat) used[t.cat] = true; });
    if (catFilter && !used[catFilter]) catFilter = '';
    var list = CATEGORIES.filter(function (c) { return used[c.id]; });
    if (list.length === 0) {
      catFilters.hidden = true;
      catFilters.innerHTML = '';
      return;
    }
    var html = '<button class="catfilter' + (catFilter === '' ? ' is-active' : '') +
               '" data-cat="" type="button">Toutes</button>';
    list.forEach(function (c) {
      html += '<button class="catfilter' + (catFilter === c.id ? ' is-active' : '') +
              '" data-cat="' + c.id + '" style="--cc:' + c.color + '" type="button">' +
              '<span class="catfilter__dot"></span>' + escapeHtml(c.label) + '</button>';
    });
    catFilters.innerHTML = html;
    catFilters.hidden = false;
  }

  function openSheet(task, prefillTitle, defaultDate) {
    editingId = task ? task.id : null;
    sheetTitle.textContent = task ? 'Modifier la tâche' : 'Nouvelle tâche';
    sheetDelete.hidden = !task;

    fTitle.value = task ? task.title : (prefillTitle || '');
    fNote.value = task ? task.note : '';
    fDate.value = task ? task.date : (defaultDate || '');
    fTime.value = task ? task.time : '';
    fLead.value = String(task ? (task.lead || 0) : 0);
    fRepeat.value = task ? (task.repeat || 'none') : 'none';
    setPrio(task ? task.prio : 'normal');
    setCat(task ? (task.cat || '') : '');

    backdrop.hidden = false;
    sheet.hidden = false;
    // force reflow pour l'animation
    void sheet.offsetWidth;
    backdrop.classList.add('is-open');
    sheet.classList.add('is-open');
    window.setTimeout(function () { fTitle.focus(); }, 60);
  }

  function closeSheet() {
    backdrop.classList.remove('is-open');
    sheet.classList.remove('is-open');
    window.setTimeout(function () {
      backdrop.hidden = true;
      sheet.hidden = true;
      editingId = null;
    }, 240);
  }

  function saveSheet() {
    var title = fTitle.value.trim();
    if (!title) {
      fTitle.focus();
      showToast('Donnez un titre à la tâche.');
      return;
    }
    var fields = {
      title: title,
      note: fNote.value.trim(),
      date: fDate.value,
      time: fDate.value ? fTime.value : '',
      prio: currentPrio,
      cat: currentCat,
      lead: parseInt(fLead.value, 10) || 0,
      repeat: fRepeat.value || 'none'
    };

    var t;
    if (editingId) {
      t = findTask(editingId);
      if (t) {
        t.title = fields.title;
        t.note = fields.note;
        t.date = fields.date;
        t.time = fields.time;
        t.prio = fields.prio;
        t.cat = fields.cat;
        t.lead = fields.lead;
        t.repeat = fields.repeat;
        t.notified = false; // l'échéance a pu changer
      }
    } else {
      t = makeTask(fields);
      tasks.push(t);
    }

    persist();
    if (t && t.date) {
      Reminders.ensurePermission();
      scheduleOne(t);
    }
    var wasEditing = !!editingId;
    closeSheet();
    renderCurrent();
    showToast(wasEditing ? 'Tâche mise à jour.' : 'Tâche ajoutée.');
  }

  function deleteCurrent() {
    if (!editingId) return;
    Reminders.clear(editingId);
    tasks = tasks.filter(function (t) { return t.id !== editingId; });
    persist();
    closeSheet();
    renderCurrent();
    showToast('Tâche supprimée.');
  }

  // ===== Rappels =====
  function remindAtMs(t) {
    var base = dueAtMs(t);
    if (base == null) return null;
    return base - (t.lead || 0) * 60000;
  }

  function buildMessage(t) {
    var body = t.note || '';
    if (t.time) body = (body ? body + ' · ' : '') + 'Prévu à ' + t.time;
    if (!body) body = 'Tâche à faire.';
    return { title: 'Rappel : ' + t.title, body: body };
  }

  function notifyTask(t) {
    var m = buildMessage(t);
    Reminders.show(m.title, m.body);
    showToast(m.title);
  }

  function scheduleOne(t) {
    if (t.done || !t.date) return;
    var at = remindAtMs(t);
    if (at == null) return;
    var m = buildMessage(t);
    Reminders.schedule(t.id, at, m.title, m.body, function () { fireReminder(t.id); });
  }

  function scheduleAll() {
    tasks.forEach(scheduleOne);
  }

  function fireReminder(id) {
    var t = findTask(id);
    if (!t || t.done || t.notified) return;
    t.notified = true;
    persist();
    notifyTask(t);
  }

  function checkDue() {
    // En natif (APK Capacitor), c'est le système qui déclenche les rappels planifiés.
    if (Reminders.isNative && Reminders.isNative()) return;
    var now = Date.now();
    var changed = false;
    tasks.forEach(function (t) {
      if (t.done || t.notified || !t.date) return;
      var at = remindAtMs(t);
      if (at != null && at <= now) {
        t.notified = true;
        changed = true;
        notifyTask(t);
      }
    });
    if (changed) persist();
  }

  // ===== Toast =====
  var toastTimer = null;
  function showToast(msg) {
    toastEl.textContent = msg;
    toastEl.hidden = false;
    void toastEl.offsetWidth;
    toastEl.classList.add('is-open');
    if (toastTimer) window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(function () {
      toastEl.classList.remove('is-open');
      window.setTimeout(function () { toastEl.hidden = true; }, 220);
    }, 2600);
  }

  // ===== Bascule de vue =====
  function switchView(name) {
    view = name;
    var btns = document.querySelectorAll('.view');
    Array.prototype.forEach.call(btns, function (b) {
      b.classList.toggle('is-active', b.getAttribute('data-view') === name);
    });
    viewTasks.hidden = name !== 'tasks';
    viewCalendar.hidden = name !== 'calendar';
    viewNotes.hidden = name !== 'notes';
    document.body.classList.remove('view-tasks', 'view-calendar', 'view-notes');
    document.body.classList.add('view-' + name);
    renderCurrent();
  }

  function renderCurrent() {
    if (view === 'calendar') renderCalendar();
    else if (view === 'notes') renderNotes();
    else render();
  }

  // Clic sur une carte de tâche (partagé entre la liste et le calendrier)
  function handleTaskClick(e) {
    var card = e.target.closest('.task');
    if (!card) return;
    var id = card.getAttribute('data-id');
    if (e.target.closest('[data-act="toggle"]')) {
      e.stopPropagation();
      toggleDone(id);
    } else {
      var t = findTask(id);
      if (t) openSheet(t);
    }
  }

  // ===== Bloc-notes (une page par jour) =====
  function fullDateLabel(dateStr) {
    var d = new Date(dateStr + 'T00:00:00');
    return capitalize(d.toLocaleDateString('fr-FR', {
      weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
    }));
  }

  function shortDate(dateStr) {
    var d = new Date(dateStr + 'T00:00:00');
    return d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });
  }

  function shiftDay(dateStr, delta) {
    var d = new Date(dateStr + 'T00:00:00');
    d.setDate(d.getDate() + delta);
    return localDateStr(d);
  }

  function setNoteStatus(text, state) {
    noteStatusEl.textContent = text;
    if (state) noteStatusEl.setAttribute('data-state', state);
    else noteStatusEl.removeAttribute('data-state');
  }

  function saveCurrentNote() {
    var text = noteTextEl.value;
    if (text.trim() === '') {
      if (notes[selectedDate]) delete notes[selectedDate];
    } else {
      notes[selectedDate] = { text: text, updatedAt: Date.now() };
    }
    Storage.saveNotes(notes);
    setNoteStatus('Enregistré', 'saved');
    renderHistory();
  }

  function scheduleNoteSave() {
    setNoteStatus('Enregistrement…', 'typing');
    if (noteSaveTimer) window.clearTimeout(noteSaveTimer);
    noteSaveTimer = window.setTimeout(function () {
      noteSaveTimer = null;
      saveCurrentNote();
    }, 500);
  }

  function flushNote() {
    if (noteSaveTimer) {
      window.clearTimeout(noteSaveTimer);
      noteSaveTimer = null;
      saveCurrentNote();
    }
  }

  function gotoDay(dateStr) {
    flushNote();
    selectedDate = dateStr;
    renderNotes();
  }

  function renderNotes() {
    renderHeroDate();
    var count = Object.keys(notes).length;
    heroSummary.innerHTML = count
      ? '<b>' + count + '</b> ' + (count > 1 ? 'jours notés' : 'jour noté')
      : 'Bloc-notes — une page par jour.';

    dayLabelEl.textContent = dayLabel(selectedDate);
    daySubEl.textContent = fullDateLabel(selectedDate);
    dayInput.value = selectedDate;

    var entry = notes[selectedDate];
    noteTextEl.value = entry ? entry.text : '';
    setNoteStatus(entry ? 'Enregistré' : '\u00A0', entry ? 'saved' : null);

    renderHistory();
  }

  function renderHistory() {
    var keys = Object.keys(notes).filter(function (k) {
      return notes[k] && notes[k].text && notes[k].text.trim() !== '';
    }).sort().reverse();

    if (keys.length === 0) {
      noteHistory.innerHTML = '<p class="notehist__empty">Vos notes des autres jours apparaîtront ici.</p>';
      return;
    }

    var html = '<p class="notehist__title">Toutes les notes</p>';
    html += keys.map(function (k) {
      var snippet = notes[k].text.replace(/\s+/g, ' ').trim().slice(0, 90);
      return '<button class="notecard' + (k === selectedDate ? ' is-current' : '') +
        '" type="button" data-day="' + k + '">' +
        '<span class="notecard__head">' +
          '<span class="notecard__day">' + escapeHtml(dayLabel(k)) + '</span>' +
          '<span class="notecard__sub">' + escapeHtml(shortDate(k)) + '</span>' +
        '</span>' +
        '<p class="notecard__snippet">' + escapeHtml(snippet) + '</p>' +
      '</button>';
    }).join('');
    noteHistory.innerHTML = html;
  }

  // ===== Thème (clair / sombre / système) =====
  function systemPrefersDark() {
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  }
  function effectiveTheme() {
    var t = settings.theme || 'system';
    return (t === 'dark' || (t === 'system' && systemPrefersDark())) ? 'dark' : 'light';
  }
  function applyTheme() {
    var eff = effectiveTheme();
    document.documentElement.setAttribute('data-theme', eff);
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', eff === 'dark' ? '#141220' : '#6555E8');
    var btns = document.querySelectorAll('[data-theme-opt]');
    Array.prototype.forEach.call(btns, function (b) {
      var on = b.getAttribute('data-theme-opt') === (settings.theme || 'system');
      b.classList.toggle('is-active', on);
      b.setAttribute('aria-checked', on ? 'true' : 'false');
    });
  }
  function setTheme(t) {
    settings.theme = t;
    Storage.saveSettings(settings);
    applyTheme();
  }

  // ===== Fond d'écran (galerie zen) =====
  var BG_COUNT = 24;
  function bgUrl(id) { return 'assets/backgrounds/' + id + '.jpg'; }
  function bgThumbUrl(id) { return 'assets/backgrounds/thumb/' + id + '.jpg'; }

  function applyBackground() {
    var id = settings.bg || '';
    if (id) {
      bgLayer.style.backgroundImage = 'url("' + bgUrl(id) + '")';
      document.body.classList.add('has-bg');
    } else {
      bgLayer.style.backgroundImage = 'none';
      document.body.classList.remove('has-bg');
    }
    markActiveBgTile();
  }

  function setBackground(id) {
    settings.bg = id || '';
    Storage.saveSettings(settings);
    applyBackground();
  }

  function markActiveBgTile() {
    if (!bgGrid) return;
    var tiles = bgGrid.querySelectorAll('.bgtile');
    Array.prototype.forEach.call(tiles, function (t) {
      t.classList.toggle('is-active', (t.getAttribute('data-bg') || '') === (settings.bg || ''));
    });
  }

  function buildBgGrid() {
    if (!bgGrid) return;
    var check = '<span class="bgtile__check">' + ICON_CHECK + '</span>';
    var html = '<button class="bgtile bgtile--none" type="button" data-bg="" aria-label="Aucun fond">Aucun' + check + '</button>';
    for (var i = 1; i <= BG_COUNT; i++) {
      var id = 'bg-' + pad(i);
      html += '<button class="bgtile" type="button" data-bg="' + id + '" aria-label="Fond ' + i + '"' +
              ' style="background-image:url(\'' + bgThumbUrl(id) + '\')">' + check + '</button>';
    }
    bgGrid.innerHTML = html;
    bgGrid.addEventListener('click', function (e) {
      var tile = e.target.closest('.bgtile');
      if (!tile) return;
      setBackground(tile.getAttribute('data-bg') || '');
    });
    markActiveBgTile();
  }

  // ===== Réglages (feuille) =====
  function openSettings() {
    backdrop.hidden = false;
    settingsSheet.hidden = false;
    void settingsSheet.offsetWidth;
    backdrop.classList.add('is-open');
    settingsSheet.classList.add('is-open');
  }
  function closeSettings() {
    backdrop.classList.remove('is-open');
    settingsSheet.classList.remove('is-open');
    window.setTimeout(function () {
      backdrop.hidden = true;
      settingsSheet.hidden = true;
    }, 240);
  }

  // ===== Export / import / effacement =====
  function exportData() {
    var payload = {
      app: 'mon-agenda', version: 1, exportedAt: new Date().toISOString(),
      tasks: tasks, notes: notes, settings: settings
    };
    var blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'mon-agenda-sauvegarde-' + localDateStr(new Date()) + '.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    showToast('Sauvegarde exportée.');
  }

  function sanitizeTasks(arr) {
    return arr.filter(function (t) { return t && typeof t.title === 'string'; })
      .map(function (t) {
        return {
          id: t.id || Storage.uid(),
          title: String(t.title),
          note: typeof t.note === 'string' ? t.note : '',
          date: typeof t.date === 'string' ? t.date : '',
          time: typeof t.time === 'string' ? t.time : '',
          prio: (t.prio === 'low' || t.prio === 'high') ? t.prio : 'normal',
          cat: (typeof t.cat === 'string' && catById(t.cat)) ? t.cat : '',
          lead: parseInt(t.lead, 10) || 0,
          repeat: (t.repeat === 'daily' || t.repeat === 'weekly' || t.repeat === 'monthly') ? t.repeat : 'none',
          done: !!t.done,
          createdAt: t.createdAt || Date.now(),
          completedAt: t.completedAt || null,
          notified: !!t.notified
        };
      });
  }

  function importData(file) {
    var reader = new FileReader();
    reader.onload = function () {
      var data;
      try { data = JSON.parse(reader.result); }
      catch (e) { showToast('Fichier illisible.'); return; }
      if (!data || typeof data !== 'object') { showToast('Sauvegarde invalide.'); return; }
      var hasTasks = Array.isArray(data.tasks);
      var hasNotes = data.notes && typeof data.notes === 'object' && !Array.isArray(data.notes);
      if (!hasTasks && !hasNotes) { showToast('Aucune donnée reconnue.'); return; }
      if (!window.confirm('Remplacer vos tâches et notes actuelles par cette sauvegarde ?')) return;

      if (hasTasks) tasks = sanitizeTasks(data.tasks);
      if (hasNotes) notes = data.notes;
      if (data.settings && typeof data.settings === 'object') {
        settings = { theme: data.settings.theme || 'system', bg: data.settings.bg || '' };
      }
      Storage.saveAll(tasks);
      Storage.saveNotes(notes);
      Storage.saveSettings(settings);
      Reminders.clearAll();
      scheduleAll();
      applyTheme();
      applyBackground();
      selectedDate = localDateStr(new Date());
      closeSettings();
      renderCurrent();
      showToast('Données importées.');
    };
    reader.onerror = function () { showToast('Lecture impossible.'); };
    reader.readAsText(file);
  }

  function clearData() {
    if (!window.confirm('Effacer définitivement toutes les tâches et toutes les notes ?')) return;
    tasks = [];
    notes = {};
    Storage.saveAll(tasks);
    Storage.saveNotes(notes);
    Reminders.clearAll();
    selectedDate = localDateStr(new Date());
    closeSettings();
    renderCurrent();
    showToast('Données effacées.');
  }

  // ===== Calendrier =====
  var MONTHS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin',
    'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];

  function startOfMonth(d) { return new Date(d.getFullYear(), d.getMonth(), 1); }

  function dayHasActiveTask(dateStr) {
    for (var i = 0; i < tasks.length; i++) {
      if (!tasks[i].done && tasks[i].date === dateStr) return true;
    }
    return false;
  }
  function dayHasNote(dateStr) {
    return !!(notes[dateStr] && notes[dateStr].text && notes[dateStr].text.trim() !== '');
  }

  function renderCalendar() {
    renderHeroDate();
    setHeroSummaryTasks();

    monthLabel.textContent = capitalize(MONTHS[calMonth.getMonth()]) + ' ' + calMonth.getFullYear();

    var first = startOfMonth(calMonth);
    var firstWeekday = (first.getDay() + 6) % 7; // lundi = 0
    var gridStart = new Date(first);
    gridStart.setDate(first.getDate() - firstWeekday);

    var todayStr = localDateStr(new Date());
    var monthIdx = calMonth.getMonth();
    var html = '';
    for (var i = 0; i < 42; i++) {
      var d = new Date(gridStart);
      d.setDate(gridStart.getDate() + i);
      var ds = localDateStr(d);
      var cls = 'cal__cell';
      if (d.getMonth() !== monthIdx) cls += ' is-out';
      if (ds === todayStr) cls += ' is-today';
      if (ds === calSelected) cls += ' is-selected';
      var dots = '';
      if (dayHasActiveTask(ds)) dots += '<span class="cal__dot cal__dot--task"></span>';
      if (dayHasNote(ds)) dots += '<span class="cal__dot cal__dot--note"></span>';
      html += '<button class="' + cls + '" type="button" data-day="' + ds + '">' +
                '<span class="cal__num">' + d.getDate() + '</span>' +
                '<span class="cal__dots">' + dots + '</span>' +
              '</button>';
    }
    calGrid.innerHTML = html;
    renderCalDetail();
  }

  function renderCalDetail() {
    var dayTasks = tasks.filter(function (t) { return t.date === calSelected; });
    dayTasks.sort(function (a, b) {
      if (!!a.done !== !!b.done) return a.done ? 1 : -1;
      return (dueAtMs(a) || 0) - (dueAtMs(b) || 0);
    });

    var head = '<div class="caldetail__head">' +
      '<h3 class="caldetail__title">' + escapeHtml(capitalize(fullDateLabel(calSelected))) + '</h3>' +
      '<button class="btn btn--primary caldetail__add" id="calAdd" type="button">+ Tâche</button></div>';

    var body = dayTasks.length
      ? dayTasks.map(taskHtml).join('')
      : '<p class="caldetail__empty">Aucune tâche ce jour-là.</p>';

    var noteText = dayHasNote(calSelected)
      ? '<p class="caldetail__note-text">' +
          escapeHtml(notes[calSelected].text.replace(/\s+/g, ' ').trim().slice(0, 160)) + '</p>'
      : '<p class="caldetail__note-text" style="color:var(--faint)">Ajouter une note pour cette journée…</p>';
    var note = '<button class="caldetail__note" id="calNote" type="button">' +
      '<p class="caldetail__note-label">Note du jour</p>' + noteText + '</button>';

    calDetail.innerHTML = head + body + note;

    var addBtn = document.getElementById('calAdd');
    if (addBtn) addBtn.addEventListener('click', function () { openSheet(null, '', calSelected); });
    var noteBtn = document.getElementById('calNote');
    if (noteBtn) noteBtn.addEventListener('click', function () { openNoteForDay(calSelected); });
  }

  function openNoteForDay(dateStr) {
    selectedDate = dateStr;
    switchView('notes');
  }

  function shiftMonth(delta) {
    calMonth = new Date(calMonth.getFullYear(), calMonth.getMonth() + delta, 1);
    renderCalendar();
  }

  // ===== Branchement des événements =====
  function bind() {
    // Ajout rapide
    $('quickAdd').addEventListener('click', quickAdd);
    quickInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); quickAdd(); }
    });
    $('quickDetails').addEventListener('click', function () {
      var v = quickInput.value.trim();
      quickInput.value = '';
      openSheet(null, v);
    });

    // FAB
    $('fab').addEventListener('click', function () { openSheet(null, ''); });

    // Bascule de vue
    var viewBtns = document.querySelectorAll('.view');
    Array.prototype.forEach.call(viewBtns, function (b) {
      b.addEventListener('click', function () { switchView(b.getAttribute('data-view')); });
    });

    // Bloc-notes
    noteTextEl.addEventListener('input', scheduleNoteSave);
    noteTextEl.addEventListener('blur', flushNote);
    $('dayPrev').addEventListener('click', function () { gotoDay(shiftDay(selectedDate, -1)); });
    $('dayNext').addEventListener('click', function () { gotoDay(shiftDay(selectedDate, 1)); });
    $('dayToday').addEventListener('click', function () { gotoDay(localDateStr(new Date())); });
    dayInput.addEventListener('change', function () {
      if (dayInput.value) gotoDay(dayInput.value);
    });
    noteHistory.addEventListener('click', function (e) {
      var card = e.target.closest('.notecard');
      if (card) gotoDay(card.getAttribute('data-day'));
    });

    // Filtres
    var filterBtns = document.querySelectorAll('.filter');
    Array.prototype.forEach.call(filterBtns, function (b) {
      b.addEventListener('click', function () {
        Array.prototype.forEach.call(filterBtns, function (x) { x.classList.remove('is-active'); });
        b.classList.add('is-active');
        filter = b.getAttribute('data-filter');
        render();
      });
    });

    // Filtres par catégorie (délégation, contenu reconstruit dynamiquement)
    if (catFilters) {
      catFilters.addEventListener('click', function (e) {
        var b = e.target.closest('.catfilter');
        if (!b) return;
        catFilter = b.getAttribute('data-cat') || '';
        render();
      });
    }

    // Sélecteur de catégorie dans la feuille
    if (catPicker) {
      catPicker.addEventListener('click', function (e) {
        var b = e.target.closest('.catpill');
        if (!b) return;
        setCat(b.getAttribute('data-cat') || '');
      });
    }

    // Recherche
    if (searchBtn) {
      searchBtn.addEventListener('click', function () {
        var show = searchBar.hidden;
        searchBar.hidden = !show;
        searchBtn.classList.toggle('is-active', show);
        if (show) {
          searchInput.focus();
        } else {
          searchInput.value = '';
          searchQuery = '';
          render();
        }
      });
      searchInput.addEventListener('input', function () {
        searchQuery = searchInput.value;
        render();
      });
      searchClear.addEventListener('click', function () {
        searchInput.value = '';
        searchQuery = '';
        searchInput.focus();
        render();
      });
    }

    // Bandeau de mise à jour
    if (updateBar) {
      $('updateBtn').addEventListener('click', applyUpdate);
    }

    // Liste + calendrier : délégation (cocher ou ouvrir)
    listEl.addEventListener('click', handleTaskClick);
    calDetail.addEventListener('click', handleTaskClick);

    // Calendrier : navigation
    $('monthPrev').addEventListener('click', function () { shiftMonth(-1); });
    $('monthNext').addEventListener('click', function () { shiftMonth(1); });
    monthLabel.addEventListener('click', function () {
      calMonth = startOfMonth(new Date());
      calSelected = localDateStr(new Date());
      renderCalendar();
    });
    calGrid.addEventListener('click', function (e) {
      var cell = e.target.closest('.cal__cell');
      if (!cell) return;
      calSelected = cell.getAttribute('data-day');
      var d = new Date(calSelected + 'T00:00:00');
      if (d.getMonth() !== calMonth.getMonth() || d.getFullYear() !== calMonth.getFullYear()) {
        calMonth = startOfMonth(d);
      }
      renderCalendar();
    });

    // Feuille (tâche)
    $('sheetSave').addEventListener('click', saveSheet);
    $('sheetCancel').addEventListener('click', closeSheet);
    $('sheetClose').addEventListener('click', closeSheet);
    sheetDelete.addEventListener('click', deleteCurrent);
    backdrop.addEventListener('click', function () {
      if (!sheet.hidden) closeSheet();
      if (!settingsSheet.hidden) closeSettings();
    });

    var segBtns = sheet.querySelectorAll('.seg__btn');
    Array.prototype.forEach.call(segBtns, function (b) {
      b.addEventListener('click', function () { setPrio(b.getAttribute('data-prio')); });
    });

    // Réglages
    $('settingsBtn').addEventListener('click', openSettings);
    $('settingsClose').addEventListener('click', closeSettings);
    $('settingsDone').addEventListener('click', closeSettings);
    var themeBtns = document.querySelectorAll('[data-theme-opt]');
    Array.prototype.forEach.call(themeBtns, function (b) {
      b.addEventListener('click', function () { setTheme(b.getAttribute('data-theme-opt')); });
    });
    $('exportBtn').addEventListener('click', exportData);
    $('importBtn').addEventListener('click', function () { $('importFile').click(); });
    $('importFile').addEventListener('change', function (e) {
      var f = e.target.files && e.target.files[0];
      if (f) importData(f);
      e.target.value = '';
    });
    $('clearBtn').addEventListener('click', clearData);

    // Suit le thème du système quand l'option « Système » est choisie
    var mq = window.matchMedia('(prefers-color-scheme: dark)');
    var onSchemeChange = function () { if ((settings.theme || 'system') === 'system') applyTheme(); };
    if (mq.addEventListener) mq.addEventListener('change', onSchemeChange);
    else if (mq.addListener) mq.addListener(onSchemeChange);

    // Échap ferme la feuille ouverte
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return;
      if (!sheet.hidden) closeSheet();
      else if (!settingsSheet.hidden) closeSettings();
    });
    fTitle.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); saveSheet(); }
    });

    // Sauvegarde des notes + vérification des échéances au changement de visibilité
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) {
        flushNote();
      } else {
        if (view === 'tasks') render();
        checkDue();
      }
    });
    window.addEventListener('beforeunload', flushNote);

    // Installation (PWA)
    window.addEventListener('beforeinstallprompt', function (e) {
      e.preventDefault();
      deferredInstall = e;
      $('installBtn').hidden = false;
    });
    $('installBtn').addEventListener('click', function () {
      if (!deferredInstall) return;
      deferredInstall.prompt();
      deferredInstall.userChoice.finally(function () {
        deferredInstall = null;
        $('installBtn').hidden = true;
      });
    });
    window.addEventListener('appinstalled', function () {
      $('installBtn').hidden = true;
    });
  }

  // ===== Service worker (hors-ligne + mises à jour) =====
  var pendingReload = false;

  function showUpdateBar() { if (updateBar) updateBar.hidden = false; }

  function applyUpdate() {
    pendingReload = true;
    if (swReg && swReg.waiting) {
      swReg.waiting.postMessage('SKIP_WAITING'); // active la nouvelle version, puis rechargement
    } else {
      window.location.reload();
    }
  }

  function registerSW() {
    // Inutile dans l'APK natif (les fichiers sont déjà embarqués) — on évite toute interférence.
    if (window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' && window.Capacitor.isNativePlatform()) return;
    if (!('serviceWorker' in navigator) || location.protocol.indexOf('http') !== 0) return;

    navigator.serviceWorker.addEventListener('controllerchange', function () {
      if (pendingReload) window.location.reload(); // uniquement après demande de l'utilisateur
    });

    navigator.serviceWorker.register('service-worker.js').then(function (reg) {
      swReg = reg;
      if (reg.waiting && navigator.serviceWorker.controller) showUpdateBar();
      reg.addEventListener('updatefound', function () {
        var sw = reg.installing;
        if (!sw) return;
        sw.addEventListener('statechange', function () {
          if (sw.state === 'installed' && navigator.serviceWorker.controller) showUpdateBar();
        });
      });
    }).catch(function () { /* ignoré */ });
  }

  // ===== Démarrage =====
  function init() {
    selectedDate = localDateStr(new Date());
    calMonth = startOfMonth(new Date());
    calSelected = localDateStr(new Date());
    applyTheme();
    buildBgGrid();
    applyBackground();
    bind();
    renderNotes(); // prépare l'éditeur et l'historique (vue cachée au départ)
    render();      // la vue Tâches est affichée au démarrage
    scheduleAll();
    checkDue();
    window.setInterval(checkDue, 30000); // re-vérifie toutes les 30 s
    registerSW();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
