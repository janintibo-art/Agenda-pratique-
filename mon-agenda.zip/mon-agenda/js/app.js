/* =========================================================
   Mon Agenda — application
   ========================================================= */
(function () {
  'use strict';

  // ----- État -----
  var tasks = Storage.load();
  var filter = 'all';            // all | active | done
  var editingId = null;
  var lastDeleted = null;        // dernière tâche supprimée (pour l'annulation)
  var snoozeTargetId = null;     // tâche visée par la feuille de report
  var currentPrio = 'normal';
  var currentCat = '';           // catégorie en cours d'édition dans la feuille
  var currentSubtasks = [];      // brouillon de sous-tâches dans la feuille
  var catFilter = '';            // filtre par catégorie ('' = toutes)
  var searchQuery = '';          // texte de recherche dans les tâches
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var deferredInstall = null;

  // Catégories prédéfinies (couleur distincte, accordée à la palette)
  var CATEGORIES = [
    { id: 'travail', label: 'Travail', color: '#4F86C6' },
    { id: 'perso',   label: 'Perso',   color: '#C76B98' },
    { id: 'sante',   label: 'Santé',   color: '#3FA08C' },
    { id: 'maison',  label: 'Maison',  color: '#D08A4E' },
    { id: 'famille', label: 'Famille', color: '#8A78C4' },
    { id: 'loisirs', label: 'Loisirs', color: '#6FA15A' },
    { id: 'anniversaire', label: 'Anniversaire', color: '#EC6A75' }
  ];
  function catById(id) {
    for (var i = 0; i < CATEGORIES.length; i++) if (CATEGORIES[i].id === id) return CATEGORIES[i];
    return null;
  }

  var view = 'tasks';            // tasks | calendar | notes
  var notes = Storage.loadNotes();
  var notebook = sanitizeNotebook(Storage.loadNotebook());
  var notebookMode = false, nbTrashMode = false, nbActive = null;
  var intentions = Storage.loadIntentions();
  var moods = Storage.loadMoods();
  var selectedDate = null;       // 'AAAA-MM-JJ' du jour affiché dans le bloc-notes
  var noteSaveTimer = null;

  var settings = Storage.loadSettings();
  var calMonth = null;           // Date du 1er du mois affiché dans le calendrier
  var calSelected = null;        // 'AAAA-MM-JJ' du jour sélectionné dans le calendrier

  // ----- Références DOM -----
  var $ = function (id) { return document.getElementById(id); };
  var heroDate = $('heroDate');
  var heroSummary = $('heroSummary');
  var listEl = $('list');
  var emptyEl = $('empty');
  var emptyTitle = $('emptyTitle');
  var emptyText = $('emptyText');
  var toastEl = $('toast');

  var quickInput = $('quickInput');
  var sheet = $('sheet');
  var backdrop = $('backdrop');
  var sheetTitle = $('sheetTitle');
  var fTitle = $('fTitle');
  var fNote = $('fNote');
  var fDate = $('fDate');
  var fTime = $('fTime');
  var dateQuick = $('dateQuick');
  var sheetDelete = $('sheetDelete');

  // Vue Notes
  var viewTasks = $('viewTasks');
  var viewNotes = $('viewNotes');
  var fabEl = $('fab');
  var noteTextEl = $('noteText');
  var noteStatusEl = $('noteStatus');
  var dayLabelEl = $('dayLabelEl');
  var daySubEl = $('daySubEl');
  var dayInput = $('dayInput');
  var noteHistory = $('noteHistory');
  var intentionInput = $('intentionInput');
  var intentionSaveTimer = null;
  var moodPicker = $('moodPicker');
  var statDone = $('statDone');
  var statStreak = $('statStreak');
  var statMood = $('statMood');
  var moodChart = $('moodChart');
  var breathBtn = $('breathBtn');
  var breathOverlay = $('breathOverlay');
  var breathCircle = $('breathCircle');
  var breathLabel = $('breathLabel');
  var breathClose = $('breathClose');
  var breathTimer = null;

  // Calendrier + réglages + champs supplémentaires
  var viewCalendar = $('viewCalendar');
  var calGrid = $('calGrid');
  var monthLabel = $('monthLabel');
  var calDetail = $('calDetail');
  var settingsSheet = $('settingsSheet');
  var snoozeSheet = $('snoozeSheet');
  var snoozeCancel = $('snoozeCancel');
  var fLead = $('fLead');
  var fRepeat = $('fRepeat');
  var subInput = $('subInput');
  var subAdd = $('subAdd');
  var subList = $('subList');
  var bgLayer = $('bgLayer');
  var bgGrid = $('bgGrid');

  // Fond sonore
  var bgMusic = $('bgMusic');
  var musicBtn = $('musicBtn');
  var musicToggle = $('musicToggle');
  var trackPicker = $('trackPicker');
  var musicVolume = $('musicVolume');
  var hapticToggle = $('hapticToggle');
  var morningToggle = $('morningToggle');

  // Recherche, filtres par catégorie, mise à jour
  var searchBtn = $('searchBtn');
  var searchBar = $('searchBar');
  var searchInput = $('searchInput');
  var searchClear = $('searchClear');
  var catFilters = $('catFilters');
  var catPicker = $('catPicker');

  // ===== Utilitaires date =====
  function pad(n) { return n < 10 ? '0' + n : '' + n; }

  function localDateStr(d) {
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }

  function dueAtMs(t) {
    if (!t.date) return null;
    var time = t.time || '09:00';
    var ms = new Date(t.date + 'T' + time + ':00').getTime();
    return isNaN(ms) ? null : ms;
  }

  function endOfDayMs(dateStr) {
    return new Date(dateStr + 'T23:59:59').getTime();
  }

  function isOverdue(t) {
    if (t.done || !t.date) return false;
    var now = Date.now();
    return t.time ? (dueAtMs(t) < now) : (endOfDayMs(t.date) < now);
  }

  function dayLabel(dateStr) {
    var today = new Date();
    var t0 = new Date(localDateStr(today) + 'T00:00:00');
    var d = new Date(dateStr + 'T00:00:00');
    var diff = Math.round((d - t0) / 86400000);
    if (diff === 0) return "Aujourd'hui";
    if (diff === 1) return 'Demain';
    if (diff === -1) return 'Hier';
    var opts = { day: 'numeric', month: 'long' };
    if (d.getFullYear() !== today.getFullYear()) opts.year = 'numeric';
    return d.toLocaleDateString('fr-FR', opts);
  }

  function capitalize(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }

  // ===== Rendu de l'en-tête =====
  function renderHeroDate() {
    var now = new Date();
    heroDate.textContent = capitalize(
      now.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' })
    );
  }

  function renderHero() {
    renderHeroDate();
    setHeroSummaryTasks();
  }

  function setHeroSummaryTasks() {
    var active = tasks.filter(function (t) { return !t.done; });
    var late = active.filter(isOverdue).length;

    if (active.length === 0) {
      heroSummary.innerHTML = tasks.length
        ? 'Tout est fait. Belle journée !'
        : 'Aucune tâche pour l’instant.';
      return;
    }
    var noun = active.length > 1 ? 'tâches' : 'tâche';
    var html = '<b>' + active.length + '</b> ' + noun + ' à faire';
    if (late > 0) html += ' · <span class="is-late">' + late + ' en retard</span>';
    heroSummary.innerHTML = html;
  }

  // ===== Construction d'une carte =====
  var ICON_CLOCK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2" stroke-linecap="round"/></svg>';
  var ICON_CHECK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M5 12l4 4 10-10" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  var ICON_SHUFFLE = '<svg class="bgtile__ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 3h5v5M4 20l17-17M21 16v5h-5M15 15l6 6M4 4l5 5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  var ICON_SOUND_ON = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5L6 9H3v6h3l5 4V5Z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13"/></svg>';
  var ICON_SOUND_OFF = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5L6 9H3v6h3l5 4V5Z"/><path d="M22 9l-6 6M16 9l6 6"/></svg>';
  var ICON_REPEAT = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 9a7 7 0 0 1 12-3l2 2M20 15a7 7 0 0 1-12 3l-2-2" stroke-linecap="round" stroke-linejoin="round"/><path d="M18 4v4h-4M6 20v-4h4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  var ICON_BELL = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" stroke-linecap="round" stroke-linejoin="round"/><path d="M13.7 21a2 2 0 0 1-3.4 0" stroke-linecap="round"/></svg>';
  var ICON_LIST = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 6h11M9 12h11M9 18h11" stroke-linecap="round"/><path d="M4 6l1 1 2-2M4 12l1 1 2-2M4 18l1 1 2-2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  var ICON_X = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>';

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function chipFor(t) {
    if (!t.date) return '';
    var late = isOverdue(t);
    var label = dayLabel(t.date);
    if (t.time) label += ' · ' + t.time;
    return '<span class="chip' + (late ? ' chip--late' : '') + '">' +
      ICON_CLOCK + escapeHtml(label) + '</span>';
  }

  function prioFor(t) {
    if (t.prio === 'high') return '<span class="prio prio--high"><span class="prio__dot"></span>Haute</span>';
    if (t.prio === 'normal') return '<span class="prio prio--normal"><span class="prio__dot"></span>Moyenne</span>';
    return '';
  }

  function repeatChipFor(t) {
    if (!t.repeat || t.repeat === 'none') return '';
    var label = t.repeat === 'daily' ? 'Chaque jour'
              : t.repeat === 'weekly' ? 'Chaque sem.' : 'Chaque mois';
    return '<span class="chip">' + ICON_REPEAT + escapeHtml(label) + '</span>';
  }

  function leadChipFor(t) {
    if (!t.date || !t.lead) return '';
    var m = t.lead, label;
    if (m >= 1440) label = (m / 1440) + ' j avant';
    else if (m >= 60) label = (m / 60) + ' h avant';
    else label = m + ' min avant';
    return '<span class="chip">' + ICON_BELL + escapeHtml(label) + '</span>';
  }

  function catChipFor(t) {
    var c = catById(t.cat);
    if (!c) return '';
    return '<span class="catchip" style="--cc:' + c.color + '">' +
      '<span class="catchip__dot"></span>' + escapeHtml(c.label) + '</span>';
  }

  // Recherche insensible aux accents et à la casse
  function normTxt(s) {
    return (s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  }
  function taskMatches(t, q) {
    return normTxt(t.title).indexOf(q) >= 0 || normTxt(t.note).indexOf(q) >= 0;
  }

  function subDoneCount(t) {
    var n = 0, s = t.subtasks || [];
    for (var i = 0; i < s.length; i++) if (s[i].done) n++;
    return n;
  }
  function subChipFor(t) {
    var s = t.subtasks || [];
    if (!s.length) return '';
    return '<span class="chip">' + ICON_LIST + subDoneCount(t) + '/' + s.length + '</span>';
  }
  function subListHtml(t) {
    var s = t.subtasks || [];
    if (!s.length) return '';
    var rows = s.map(function (sub) {
      return '<li class="subtask' + (sub.done ? ' done' : '') + '" data-sub="' + sub.id + '">' +
        '<button class="subtask__check" type="button" data-subtoggle="' + sub.id + '" aria-label="' +
          (sub.done ? 'Décocher' : 'Cocher') + '">' + ICON_CHECK + '</button>' +
        '<span class="subtask__title">' + escapeHtml(sub.title) + '</span>' +
      '</li>';
    }).join('');
    return '<ul class="subtasks">' + rows + '</ul>';
  }

  function snoozeChipFor(t) {
    if (typeof t.snoozeUntil !== 'number' || t.snoozeUntil <= Date.now() || t.done) return '';
    return '<span class="chip chip--snooze">' + ICON_BELL + 'Reporté à ' + escapeHtml(snoozeLabel(t.snoozeUntil)) + '</span>';
  }
  function snoozeBtnFor(t) {
    if (!isOverdue(t) || t.done) return '';
    return '<button class="snoozebtn" type="button" data-snooze-open="' + t.id + '">' + ICON_BELL + 'Reporter</button>';
  }

  function taskHtml(t) {
    var meta = chipFor(t) + catChipFor(t) + subChipFor(t) + leadChipFor(t) +
               snoozeChipFor(t) + repeatChipFor(t) + prioFor(t) + snoozeBtnFor(t);
    return '' +
      '<article class="task' + (t.done ? ' done' : '') + (isOverdue(t) ? ' task--late' : '') +
        '" data-id="' + t.id + '">' +
        '<button class="check" type="button" data-act="toggle" aria-label="' +
          (t.done ? 'Marquer à faire' : 'Marquer terminé') + '">' + ICON_CHECK + '</button>' +
        '<div class="task__body">' +
          '<p class="task__title">' + escapeHtml(t.title) + '</p>' +
          (t.note ? '<p class="task__note">' + escapeHtml(t.note) + '</p>' : '') +
          (meta ? '<div class="task__meta">' + meta + '</div>' : '') +
          subListHtml(t) +
        '</div>' +
      '</article>';
  }

  // ===== Regroupement + rendu de la liste =====
  function sectionHtml(title, items, extraClass) {
    if (!items.length) return '';
    var cards = items.map(taskHtml).join('');
    return '<section class="section ' + (extraClass || '') + '">' +
      '<div class="section__head"><h2 class="section__title">' + title + '</h2>' +
      '<span class="section__count">' + items.length + '</span></div>' +
      cards + '</section>';
  }

  function byDueAsc(a, b) { return (dueAtMs(a) || 0) - (dueAtMs(b) || 0); }
  function byCreatedDesc(a, b) { return (b.createdAt || 0) - (a.createdAt || 0); }
  function byDoneDesc(a, b) { return (b.completedAt || b.createdAt || 0) - (a.completedAt || a.createdAt || 0); }

  function render() {
    renderHero();
    renderCatFilters();

    var todayStr = localDateStr(new Date());
    var q = normTxt(searchQuery.trim());
    var pool = tasks.filter(function (t) {
      if (filter === 'active' && t.done) return false;
      if (filter === 'done' && !t.done) return false;
      if (catFilter && (t.cat || '') !== catFilter) return false;
      if (q && !taskMatches(t, q)) return false;
      return true;
    });

    var late = [], today = [], upcoming = [], noDate = [], done = [];
    pool.forEach(function (t) {
      if (t.done) { done.push(t); return; }
      if (!t.date) { noDate.push(t); return; }
      if (isOverdue(t)) { late.push(t); return; }
      if (t.date === todayStr) { today.push(t); return; }
      upcoming.push(t);
    });

    late.sort(byDueAsc); today.sort(byDueAsc); upcoming.sort(byDueAsc);
    noDate.sort(byCreatedDesc); done.sort(byDoneDesc);

    var html = '';
    if (filter !== 'done') {
      html += sectionHtml('En retard', late, 'section--late');
      html += sectionHtml("Aujourd'hui", today);
      html += sectionHtml('À venir', upcoming);
      html += sectionHtml('Sans échéance', noDate);
    }
    if (filter !== 'active') {
      html += sectionHtml('Terminé', done);
    }

    listEl.innerHTML = html;

    if (html === '') {
      emptyEl.hidden = false;
      if (q || catFilter) {
        emptyTitle.textContent = 'Aucun résultat';
        emptyText.textContent = 'Aucune tâche ne correspond à votre recherche ou à ce filtre.';
      } else if (tasks.length === 0) {
        emptyTitle.textContent = 'Rien de prévu';
        emptyText.textContent = 'Commencez par ajouter votre première tâche ci-dessus.';
      } else if (filter === 'done') {
        emptyTitle.textContent = 'Aucune tâche terminée';
        emptyText.textContent = 'Les tâches cochées apparaîtront ici.';
      } else {
        emptyTitle.textContent = 'Tout est fait';
        emptyText.textContent = 'Aucune tâche en attente. Profitez-en !';
      }
    } else {
      emptyEl.hidden = true;
    }
  }

  // ===== Création / modification =====
  function makeTask(fields) {
    return {
      id: Storage.uid(),
      title: fields.title,
      note: fields.note || '',
      date: fields.date || '',
      time: fields.time || '',
      prio: fields.prio || 'normal',
      cat: fields.cat || '',
      subtasks: Array.isArray(fields.subtasks) ? fields.subtasks : [],
      lead: fields.lead || 0,
      repeat: fields.repeat || 'none',
      done: false,
      createdAt: Date.now(),
      completedAt: null,
      notified: false,
      snoozeUntil: null
    };
  }

  function persist() { Storage.saveAll(tasks); scheduleMorningSummary(); }

  function findTask(id) {
    for (var i = 0; i < tasks.length; i++) if (tasks[i].id === id) return tasks[i];
    return null;
  }

  function quickAdd() {
    var title = quickInput.value.trim();
    if (!title) { quickInput.focus(); return; }
    tasks.push(makeTask({ title: title }));
    persist();
    quickInput.value = '';
    render();
  }

  function markTaskDone(t) {
    t.done = true;
    t.completedAt = Date.now();
    Reminders.clear(t.id);
    clearSnooze(t);
    spawnNextOccurrence(t);
    persist();
  }

  function toggleDone(id) {
    var t = findTask(id);
    if (!t) return;
    if (!t.done) {
      var finish = function () {
        markTaskDone(t);
        renderCurrent();
      };
      hapticTap('success');
      var scope = (view === 'calendar') ? calDetail : listEl;
      var el = scope.querySelector('.task[data-id="' + id + '"]');
      if (reduceMotion || !el) { finish(); return; }
      el.classList.add('is-completing');
      window.setTimeout(finish, 220);
    } else {
      t.done = false;
      t.completedAt = null;
      t.notified = false;
      persist();
      scheduleOne(t);
      renderCurrent();
    }
  }

  // Appui sur un bouton d'une notification native (Terminer / Reporter), app fermée ou non.
  function handleNotificationAction(taskId, actionId) {
    var t = findTask(taskId);
    if (!t) return;
    if (actionId === 'SNOOZE') {
      applySnooze(taskId, Date.now() + 10 * 60000); // applySnooze persiste + replanifie + rend
      return;
    }
    if (actionId === 'DONE') {
      if (!t.done) markTaskDone(t);
    }
    renderCurrent();
  }

  function spawnNextOccurrence(t) {
    if (!t.repeat || t.repeat === 'none' || !t.date) return;
    var freshSubs = Array.isArray(t.subtasks)
      ? t.subtasks.map(function (s) { return { id: Storage.uid(), title: s.title, done: false }; })
      : [];
    var next = makeTask({
      title: t.title, note: t.note, date: advanceDate(t.date, t.repeat),
      time: t.time, prio: t.prio, cat: t.cat, subtasks: freshSubs, lead: t.lead, repeat: t.repeat
    });
    tasks.push(next);
    scheduleOne(next);
  }

  function advanceDate(dateStr, repeat) {
    var d = new Date(dateStr + 'T00:00:00');
    if (repeat === 'daily') {
      d.setDate(d.getDate() + 1);
    } else if (repeat === 'weekly') {
      d.setDate(d.getDate() + 7);
    } else if (repeat === 'monthly') {
      var day = d.getDate();
      d.setDate(1);
      d.setMonth(d.getMonth() + 1);
      var lastDay = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
      d.setDate(Math.min(day, lastDay));
    }
    return localDateStr(d);
  }

  // ===== Feuille d'édition =====
  function setPrio(value) {
    currentPrio = value;
    var btns = sheet.querySelectorAll('.seg__btn');
    for (var i = 0; i < btns.length; i++) {
      var on = btns[i].getAttribute('data-prio') === value;
      btns[i].classList.toggle('is-active', on);
      btns[i].setAttribute('aria-checked', on ? 'true' : 'false');
    }
  }

  function setCat(value) {
    currentCat = value || '';
    if (!catPicker) return;
    var btns = catPicker.querySelectorAll('.catpill');
    for (var i = 0; i < btns.length; i++) {
      var on = (btns[i].getAttribute('data-cat') || '') === currentCat;
      btns[i].classList.toggle('is-active', on);
      btns[i].setAttribute('aria-checked', on ? 'true' : 'false');
    }
  }

  // Barre de filtres par catégorie (affichée seulement si des catégories sont utilisées)
  function renderCatFilters() {
    if (!catFilters) return;
    var used = {};
    tasks.forEach(function (t) { if (t.cat) used[t.cat] = true; });
    if (catFilter && !used[catFilter]) catFilter = '';
    var list = CATEGORIES.filter(function (c) { return used[c.id]; });
    if (list.length === 0) {
      catFilters.hidden = true;
      catFilters.innerHTML = '';
      return;
    }
    var html = '<button class="catfilter' + (catFilter === '' ? ' is-active' : '') +
               '" data-cat="" type="button">Toutes</button>';
    list.forEach(function (c) {
      html += '<button class="catfilter' + (catFilter === c.id ? ' is-active' : '') +
              '" data-cat="' + c.id + '" style="--cc:' + c.color + '" type="button">' +
              '<span class="catfilter__dot"></span>' + escapeHtml(c.label) + '</button>';
    });
    catFilters.innerHTML = html;
    catFilters.hidden = false;
  }

  // ---- Date express (Aujourd'hui / Demain / Ce week-end) ----
  function quickDateStr(preset) {
    var d = new Date();
    if (preset === 'tomorrow') {
      d.setDate(d.getDate() + 1);
    } else if (preset === 'weekend') {
      var g = d.getDay(); // 0=dim .. 6=sam
      if (g !== 0 && g !== 6) d.setDate(d.getDate() + (6 - g)); // prochain samedi
      // si on est déjà samedi ou dimanche, on garde aujourd'hui
    }
    return localDateStr(d);
  }
  function setQuickDate(preset) {
    fDate.value = quickDateStr(preset);
    reflectQuickDate();
  }
  function reflectQuickDate() {
    if (!dateQuick) return;
    var val = fDate.value;
    var btns = dateQuick.querySelectorAll('.dquick__btn');
    Array.prototype.forEach.call(btns, function (b) {
      var on = !!val && quickDateStr(b.getAttribute('data-quick')) === val;
      b.classList.toggle('is-active', on);
    });
  }

  // ---- Éditeur de sous-tâches dans la feuille (brouillon) ----
  function renderSubEditor() {
    if (!subList) return;
    subList.innerHTML = (currentSubtasks || []).map(function (s) {
      return '<li class="sub-item' + (s.done ? ' done' : '') + '" data-sub="' + s.id + '">' +
        '<button class="subtask__check" type="button" data-draft-toggle="' + s.id + '" aria-label="' +
          (s.done ? 'Décocher' : 'Cocher') + '">' + ICON_CHECK + '</button>' +
        '<span class="sub-item__title">' + escapeHtml(s.title) + '</span>' +
        '<button class="sub-item__del" type="button" data-draft-del="' + s.id + '" aria-label="Supprimer l\'étape">' + ICON_X + '</button>' +
      '</li>';
    }).join('');
  }
  function addSubFromInput() {
    if (!subInput) return;
    var v = subInput.value.trim();
    if (!v) return;
    currentSubtasks.push({ id: Storage.uid(), title: v, done: false });
    subInput.value = '';
    renderSubEditor();
    subInput.focus();
  }
  function draftToggleSub(id) {
    for (var i = 0; i < currentSubtasks.length; i++) {
      if (currentSubtasks[i].id === id) { currentSubtasks[i].done = !currentSubtasks[i].done; break; }
    }
    renderSubEditor();
  }
  function draftDelSub(id) {
    currentSubtasks = currentSubtasks.filter(function (s) { return s.id !== id; });
    renderSubEditor();
  }

  function openSheet(task, prefillTitle, defaultDate) {
    editingId = task ? task.id : null;
    sheetTitle.textContent = task ? 'Modifier la tâche' : 'Nouvelle tâche';
    sheetDelete.hidden = !task;

    fTitle.value = task ? task.title : (prefillTitle || '');
    fNote.value = task ? task.note : '';
    fDate.value = task ? task.date : (defaultDate || '');
    fTime.value = task ? task.time : '';
    fLead.value = String(task ? (task.lead || 0) : 0);
    fRepeat.value = task ? (task.repeat || 'none') : 'none';
    setPrio(task ? task.prio : 'normal');
    setCat(task ? (task.cat || '') : '');
    currentSubtasks = (task && Array.isArray(task.subtasks))
      ? task.subtasks.map(function (s) { return { id: s.id, title: s.title, done: !!s.done }; })
      : [];
    if (subInput) subInput.value = '';
    renderSubEditor();
    reflectQuickDate();

    backdrop.hidden = false;
    sheet.hidden = false;
    // force reflow pour l'animation
    void sheet.offsetWidth;
    backdrop.classList.add('is-open');
    sheet.classList.add('is-open');
    window.setTimeout(function () { fTitle.focus(); }, 60);
  }

  function closeSheet() {
    backdrop.classList.remove('is-open');
    sheet.classList.remove('is-open');
    window.setTimeout(function () {
      backdrop.hidden = true;
      sheet.hidden = true;
      editingId = null;
    }, 240);
  }

  function saveSheet() {
    var title = fTitle.value.trim();
    if (!title) {
      fTitle.focus();
      showToast('Donnez un titre à la tâche.');
      return;
    }
    var cleanSubs = (currentSubtasks || [])
      .map(function (s) { return { id: s.id, title: String(s.title || '').trim(), done: !!s.done }; })
      .filter(function (s) { return s.title; });

    var fields = {
      title: title,
      note: fNote.value.trim(),
      date: fDate.value,
      time: fDate.value ? fTime.value : '',
      prio: currentPrio,
      cat: currentCat,
      subtasks: cleanSubs,
      lead: parseInt(fLead.value, 10) || 0,
      repeat: fRepeat.value || 'none'
    };

    var t;
    if (editingId) {
      t = findTask(editingId);
      if (t) {
        t.title = fields.title;
        t.note = fields.note;
        t.date = fields.date;
        t.time = fields.time;
        t.prio = fields.prio;
        t.cat = fields.cat;
        t.subtasks = fields.subtasks;
        t.lead = fields.lead;
        t.repeat = fields.repeat;
        t.notified = false; // l'échéance a pu changer
        t.snoozeUntil = null; // une réécriture de l'échéance annule un report
      }
    } else {
      t = makeTask(fields);
      tasks.push(t);
    }

    persist();
    if (t && t.date) {
      Reminders.ensurePermission();
      scheduleOne(t);
    }
    var wasEditing = !!editingId;
    closeSheet();
    renderCurrent();
    showToast(wasEditing ? 'Tâche mise à jour.' : 'Tâche ajoutée.');
  }

  function deleteCurrent() {
    if (!editingId) return;
    var victim = findTask(editingId);
    if (!victim) { closeSheet(); return; }
    lastDeleted = JSON.parse(JSON.stringify(victim)); // copie pour l'annulation
    Reminders.clear(editingId);
    tasks = tasks.filter(function (t) { return t.id !== editingId; });
    persist();
    closeSheet();
    renderCurrent();
    showToast('Tâche supprimée.', { label: 'Annuler', fn: undoDelete });
  }

  function undoDelete() {
    if (!lastDeleted) return;
    var t = lastDeleted;
    lastDeleted = null;
    if (!findTask(t.id)) tasks.push(t);
    persist();
    renderCurrent();
    if (t.date && !t.done) { Reminders.ensurePermission(); scheduleOne(t); }
    showToast('Tâche restaurée.');
  }

  // ===== Rappels =====
  function remindAtMs(t) {
    if (typeof t.snoozeUntil === 'number') return t.snoozeUntil; // report en cours
    var base = dueAtMs(t);
    if (base == null) return null;
    return base - (t.lead || 0) * 60000;
  }

  // Calcule l'instant de report selon un préréglage.
  function snoozePresetMs(preset) {
    var now = Date.now();
    if (preset === '10') return now + 10 * 60000;
    if (preset === '60') return now + 60 * 60000;
    if (preset === '180') return now + 180 * 60000;
    if (preset === 'tomorrow') {
      var d = new Date();
      d.setDate(d.getDate() + 1);
      d.setHours(8, 0, 0, 0);
      return d.getTime();
    }
    return now + 10 * 60000;
  }

  function snoozeLabel(ms) {
    var d = new Date(ms);
    var hh = pad2(d.getHours()) + ':' + pad2(d.getMinutes());
    var today = new Date(); today.setHours(0, 0, 0, 0);
    var day = new Date(ms); day.setHours(0, 0, 0, 0);
    var diff = Math.round((day - today) / 86400000);
    if (diff <= 0) return hh;
    if (diff === 1) return 'demain ' + hh;
    return d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' }) + ' ' + hh;
  }
  function pad2(n) { return (n < 10 ? '0' : '') + n; }

  function applySnooze(id, fireAtMs) {
    var t = findTask(id);
    if (!t) return;
    t.snoozeUntil = fireAtMs;
    t.notified = false; // pourra se redéclencher
    persist();
    Reminders.clear(id);
    Reminders.ensurePermission();
    scheduleOne(t);
    renderCurrent();
    showToast('Rappel reporté à ' + snoozeLabel(fireAtMs) + '.');
  }

  function clearSnooze(t) { if (t) t.snoozeUntil = null; }

  function buildMessage(t) {
    var body = t.note || '';
    if (t.time) body = (body ? body + ' · ' : '') + 'Prévu à ' + t.time;
    if (!body) body = 'Tâche à faire.';
    return { title: 'Rappel : ' + t.title, body: body };
  }

  function notifyTask(t) {
    var m = buildMessage(t);
    Reminders.show(m.title, m.body);
    showToast(m.title, { label: 'Reporter', fn: function () { openSnoozeSheet(t.id); } });
  }

  function scheduleOne(t) {
    if (t.done || !t.date) return;
    var at = remindAtMs(t);
    if (at == null) return;
    var m = buildMessage(t);
    Reminders.schedule(t.id, at, m.title, m.body, function () { fireReminder(t.id); });
  }

  function scheduleAll() {
    tasks.forEach(scheduleOne);
    scheduleMorningSummary();
  }

  // ===== Résumé du matin =====
  var MORNING_ID = '__morning__';
  var MORNING_HOUR = 8;

  function morningSummaryPlan() {
    var target = new Date();
    target.setHours(MORNING_HOUR, 0, 0, 0);
    if (target.getTime() <= Date.now()) target.setDate(target.getDate() + 1);
    var dayStr = localDateStr(target);

    var todays = tasks.filter(function (t) { return !t.done && t.date === dayStr; });
    var n = todays.length;
    if (n === 0) return null;

    var preview = todays.slice(0, 2).map(function (t) { return t.title; }).join(', ');
    var body = n + (n > 1 ? ' tâches' : ' tâche') + ' aujourd\'hui' +
               (preview ? ' : ' + preview : '') + (n > 2 ? '…' : '');
    return { day: dayStr, count: n, body: body, fireAt: target.getTime() };
  }

  function scheduleMorningSummary() {
    Reminders.clear(MORNING_ID);
    if (!settings.morningSummary) return;
    var plan = morningSummaryPlan();
    if (!plan) return;
    var title = 'Bonjour !';
    Reminders.schedule(MORNING_ID, plan.fireAt, title, plan.body, function () {
      Reminders.show(title, plan.body);  // repli web : affiche puis replanifie le lendemain
      scheduleMorningSummary();
    }, { noActions: true });
  }

  function fireReminder(id) {
    var t = findTask(id);
    if (!t || t.done || t.notified) return;
    t.notified = true;
    clearSnooze(t);
    persist();
    notifyTask(t);
  }

  function checkDue() {
    // En natif (APK Capacitor), c'est le système qui déclenche les rappels planifiés.
    if (Reminders.isNative && Reminders.isNative()) return;
    var now = Date.now();
    var changed = false;
    tasks.forEach(function (t) {
      if (t.done || t.notified || !t.date) return;
      var at = remindAtMs(t);
      if (at != null && at <= now) {
        t.notified = true;
        clearSnooze(t);
        changed = true;
        notifyTask(t);
      }
    });
    if (changed) persist();
  }

  // ===== Toast =====
  var toastTimer = null;
  var toastAction = null;        // callback du bouton d'action du toast (ex. Annuler)

  function hideToastNow() {
    if (toastTimer) { window.clearTimeout(toastTimer); toastTimer = null; }
    toastEl.classList.remove('is-open');
    window.setTimeout(function () { toastEl.hidden = true; }, 220);
  }

  function showToast(msg, action) {
    var hasAction = !!(action && action.label && typeof action.fn === 'function');
    toastAction = hasAction ? action.fn : null;
    toastEl.innerHTML = '<span class="toast__msg">' + escapeHtml(msg) + '</span>' +
      (hasAction ? '<button class="toast__action" type="button">' + escapeHtml(action.label) + '</button>' : '');
    toastEl.classList.toggle('toast--action', hasAction);
    toastEl.hidden = false;
    void toastEl.offsetWidth;
    toastEl.classList.add('is-open');
    if (toastTimer) window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(function () {
      toastEl.classList.remove('is-open');
      window.setTimeout(function () { toastEl.hidden = true; }, 220);
    }, hasAction ? 6000 : 2600);
  }

  // ===== Bascule de vue =====
  function switchView(name) {
    flushNote(); flushIntention();
    view = name;
    var btns = document.querySelectorAll('.view');
    Array.prototype.forEach.call(btns, function (b) {
      b.classList.toggle('is-active', b.getAttribute('data-view') === name);
    });
    viewTasks.hidden = name !== 'tasks';
    viewCalendar.hidden = name !== 'calendar';
    viewNotes.hidden = name !== 'notes';
    document.body.classList.remove('view-tasks', 'view-calendar', 'view-notes');
    document.body.classList.add('view-' + name);
    renderCurrent();
  }

  function renderCurrent() {
    if (view === 'calendar') renderCalendar();
    else if (view === 'notes') renderNotes();
    else render();
  }

  // Clic sur une carte de tâche (partagé entre la liste et le calendrier)
  function handleTaskClick(e) {
    var card = e.target.closest('.task');
    if (!card) return;
    var id = card.getAttribute('data-id');
    var snz = e.target.closest('[data-snooze-open]');
    if (snz) {
      e.stopPropagation();
      openSnoozeSheet(snz.getAttribute('data-snooze-open'));
      return;
    }
    var subBtn = e.target.closest('[data-subtoggle]');
    if (subBtn) {
      e.stopPropagation();
      toggleSubtask(id, subBtn.getAttribute('data-subtoggle'));
      return;
    }
    if (e.target.closest('[data-act="toggle"]')) {
      e.stopPropagation();
      toggleDone(id);
    } else {
      var t = findTask(id);
      if (t) openSheet(t);
    }
  }

  function toggleSubtask(taskId, subId) {
    var t = findTask(taskId);
    if (!t || !t.subtasks) return;
    for (var i = 0; i < t.subtasks.length; i++) {
      if (t.subtasks[i].id === subId) {
        t.subtasks[i].done = !t.subtasks[i].done;
        if (t.subtasks[i].done) hapticTap('light');
        break;
      }
    }
    Storage.saveAll(tasks);
    renderCurrent();
  }

  // ===== Bloc-notes (une page par jour) =====
  function fullDateLabel(dateStr) {
    var d = new Date(dateStr + 'T00:00:00');
    return capitalize(d.toLocaleDateString('fr-FR', {
      weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
    }));
  }

  function shortDate(dateStr) {
    var d = new Date(dateStr + 'T00:00:00');
    return d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });
  }

  function shiftDay(dateStr, delta) {
    var d = new Date(dateStr + 'T00:00:00');
    d.setDate(d.getDate() + delta);
    return localDateStr(d);
  }

  function setNoteStatus(text, state) {
    noteStatusEl.textContent = text;
    if (state) noteStatusEl.setAttribute('data-state', state);
    else noteStatusEl.removeAttribute('data-state');
  }

  function saveCurrentNote() {
    var text = noteTextEl.value;
    if (text.trim() === '') {
      if (notes[selectedDate]) delete notes[selectedDate];
    } else {
      notes[selectedDate] = { text: text, updatedAt: Date.now() };
    }
    var ok = Storage.saveNotes(notes);
    setNoteStatus(ok ? 'Enregistré' : 'Échec de sauvegarde — exportez vos données', ok ? 'saved' : 'error');
    renderHistory();
    renderStats();
  }

  function scheduleNoteSave() {
    setNoteStatus('Enregistrement…', 'typing');
    if (noteSaveTimer) window.clearTimeout(noteSaveTimer);
    noteSaveTimer = window.setTimeout(function () {
      noteSaveTimer = null;
      saveCurrentNote();
    }, 500);
  }

  function flushNote() {
    if (noteSaveTimer) {
      window.clearTimeout(noteSaveTimer);
      noteSaveTimer = null;
      saveCurrentNote();
    }
  }

  function saveCurrentIntention() {
    if (!intentionInput) return;
    var text = intentionInput.value.trim();
    if (text === '') {
      if (intentions[selectedDate]) delete intentions[selectedDate];
    } else {
      intentions[selectedDate] = { text: text, updatedAt: Date.now() };
    }
    Storage.saveIntentions(intentions);
    renderStats();
  }

  function scheduleIntentionSave() {
    if (intentionSaveTimer) window.clearTimeout(intentionSaveTimer);
    intentionSaveTimer = window.setTimeout(function () {
      intentionSaveTimer = null;
      saveCurrentIntention();
    }, 500);
  }

  function flushIntention() {
    if (intentionSaveTimer) {
      window.clearTimeout(intentionSaveTimer);
      intentionSaveTimer = null;
      saveCurrentIntention();
    }
  }

  function setMood(level) {
    var current = moods[selectedDate] ? moods[selectedDate].level : 0;
    if (level === current) {
      delete moods[selectedDate]; // re-cliquer sur la même humeur l'enlève
    } else {
      moods[selectedDate] = { level: level, updatedAt: Date.now() };
    }
    Storage.saveMoods(moods);
    reflectMood();
    renderStats();
  }

  function reflectMood() {
    if (!moodPicker) return;
    var level = moods[selectedDate] ? moods[selectedDate].level : 0;
    var btns = moodPicker.querySelectorAll('.mood__btn');
    Array.prototype.forEach.call(btns, function (b) {
      var on = parseInt(b.getAttribute('data-mood'), 10) === level;
      b.classList.toggle('is-active', on);
      b.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    moodPicker.classList.toggle('has-mood', level > 0);
  }

  // ----- Statistiques de la semaine -----
  function last7Days() {
    var arr = [], d = new Date();
    d.setDate(d.getDate() - 6);
    for (var i = 0; i < 7; i++) { arr.push(localDateStr(d)); d.setDate(d.getDate() + 1); }
    return arr;
  }
  function dayActive(ds) {
    if (notes[ds] && notes[ds].text && notes[ds].text.trim()) return true;
    if (intentions[ds] && intentions[ds].text && intentions[ds].text.trim()) return true;
    if (moods[ds]) return true;
    for (var i = 0; i < tasks.length; i++) {
      var t = tasks[i];
      if (t.completedAt && localDateStr(new Date(t.completedAt)) === ds) return true;
    }
    return false;
  }
  function currentStreak() {
    var s = 0, d = new Date();
    while (dayActive(localDateStr(d))) { s++; d.setDate(d.getDate() - 1); }
    return s;
  }
  function doneLast7Count() {
    var d = new Date(); d.setDate(d.getDate() - 6); d.setHours(0, 0, 0, 0);
    var start = d.getTime(), n = 0;
    for (var i = 0; i < tasks.length; i++) {
      if (tasks[i].completedAt && tasks[i].completedAt >= start) n++;
    }
    return n;
  }
  var MOOD_LABELS = { 0: '—', 1: 'Difficile', 2: 'Bof', 3: 'Neutre', 4: 'Bien', 5: 'Super' };

  function renderStats() {
    if (!moodChart) return;
    var days = last7Days();
    var todayS = localDateStr(new Date());

    if (statDone) statDone.textContent = String(doneLast7Count());
    if (statStreak) statStreak.textContent = String(currentStreak());

    var sum = 0, cnt = 0;
    days.forEach(function (ds) {
      var lvl = moods[ds] ? moods[ds].level : 0;
      if (lvl) { sum += lvl; cnt++; }
    });
    if (statMood) statMood.textContent = cnt ? (Math.round(sum / cnt * 10) / 10).toFixed(1) : '—';

    moodChart.innerHTML = days.map(function (ds) {
      var lvl = moods[ds] ? moods[ds].level : 0;
      var h = lvl ? Math.round(lvl / 5 * 100) : 0;
      var initial = new Date(ds + 'T00:00:00').toLocaleDateString('fr-FR', { weekday: 'narrow' });
      return '<div class="moodbar' + (ds === todayS ? ' is-today' : '') + '" title="' + MOOD_LABELS[lvl] + '">' +
        '<div class="moodbar__track"><div class="moodbar__fill" data-lvl="' + lvl + '" style="height:' + h + '%"></div></div>' +
        '<span class="moodbar__day">' + escapeHtml(initial) + '</span>' +
      '</div>';
    }).join('');
  }

  function gotoDay(dateStr) {
    flushNote();
    flushIntention();
    selectedDate = dateStr;
    renderNotes();
  }

  function renderNotes() {
    flushNote(); flushIntention();
    renderHeroDate();
    var count = Object.keys(notes).length;
    heroSummary.innerHTML = count
      ? '<b>' + count + '</b> ' + (count > 1 ? 'jours notés' : 'jour noté')
      : 'Bloc-notes — une page par jour.';

    dayLabelEl.textContent = dayLabel(selectedDate);
    daySubEl.textContent = fullDateLabel(selectedDate);
    dayInput.value = selectedDate;

    var entry = notes[selectedDate];
    noteTextEl.value = entry ? entry.text : '';
    setNoteStatus(entry ? 'Enregistré' : '\u00A0', entry ? 'saved' : null);

    if (intentionInput) {
      var intent = intentions[selectedDate];
      intentionInput.value = intent ? intent.text : '';
    }
    reflectMood();
    renderStats();

    renderHistory();
    if (notebookMode && !nbActive) renderNotebook();
    if (notebookMode) heroSummary.textContent = 'Carnet de notes — vos idées à portée de main.';
  }

  function renderHistory() {
    var keys = Object.keys(notes).filter(function (k) {
      return notes[k] && notes[k].text && notes[k].text.trim() !== '';
    }).sort().reverse();

    var q = normTxt($('journalSearch').value.trim());
    if (q) keys = keys.filter(function(k) { return normTxt(notes[k].text + ' ' + k + ' ' + fullDateLabel(k) + ' ' + shortDate(k)).indexOf(q) >= 0; });
    if (q && keys.length === 0) { noteHistory.textContent = 'Aucune note trouvée.'; return; }
    if (keys.length === 0) {
      noteHistory.innerHTML = '<p class="notehist__empty">Vos notes des autres jours apparaîtront ici.</p>';
      return;
    }

    var html = '<p class="notehist__title">Toutes les notes</p>';
    html += keys.map(function (k) {
      var snippet = notes[k].text.replace(/\s+/g, ' ').trim().slice(0, 90);
      return '<button class="notecard' + (k === selectedDate ? ' is-current' : '') +
        '" type="button" data-day="' + escapeHtml(k) + '">' +
        '<span class="notecard__head">' +
          '<span class="notecard__day">' + escapeHtml(dayLabel(k)) + '</span>' +
          '<span class="notecard__sub">' + escapeHtml(shortDate(k)) + '</span>' +
        '</span>' +
        '<p class="notecard__snippet">' + escapeHtml(snippet) + '</p>' +
      '</button>';
    }).join('');
    noteHistory.innerHTML = html;
  }

  // ===== Carnet de notes indépendant du journal =====
  function sanitizeNotebook(list) {
    var seen = Object.create(null);
    return (Array.isArray(list) ? list : []).filter(function(n) { return n && typeof n === 'object'; }).map(function(n) {
      var id = typeof n.id === 'string' && /^[a-zA-Z0-9_-]+$/.test(n.id) && !seen[n.id] ? n.id : Storage.uid();
      seen[id] = true;
      return {id:id, title:typeof n.title === 'string' ? n.title : '', text:typeof n.text === 'string' ? n.text : '',
        color:['neutral','gold','sage','blue','rose'].indexOf(n.color) >= 0 ? n.color : 'neutral', pinned:!!n.pinned,
        updatedAt:typeof n.updatedAt === 'number' && isFinite(n.updatedAt) ? n.updatedAt : Date.now(),
        deleted:!!n.deleted, items:Array.isArray(n.items) ? n.items.filter(function(i){return i && typeof i.text === 'string';}).map(function(i){return {text:i.text, done:!!i.done};}) : []};
    });
  }
  function nbPersist() {
    var ok = Storage.saveNotebook(notebook);
    $('nbStatus').textContent = ok ? 'Enregistré' : 'Échec de sauvegarde — exportez vos données';
    $('nbStatus').classList.toggle('nb-danger', !ok);
    if (!ok) showToast('Stockage indisponible. Exportez vos données.');
    return ok;
  }
  function setNotebookMode(value) {
    flushNote(); flushIntention(); notebookMode = value;
    $('journalPanel').hidden = value; $('notebookPanel').hidden = !value;
    ['journalTab','notebookTab'].forEach(function(id) {
      var active = (id === 'notebookTab') === value;
      $(id).classList.toggle('btn--primary', active); $(id).classList.toggle('btn--ghost', !active);
      $(id).setAttribute('aria-pressed', String(active));
    });
    if (value) { heroSummary.textContent = 'Carnet de notes — vos idées à portée de main.'; if (!nbActive) renderNotebook(); }
    else renderNotes();
  }
  function nbNode(tag, cls, text) {
    var el = document.createElement(tag); if (cls) el.className = cls; if (text != null) el.textContent = text; return el;
  }
  function renderNotebook() {
    $('nbBrowse').hidden = false; $('nbEditor').hidden = true;
    $('nbTrash').setAttribute('aria-pressed', String(nbTrashMode));
    $('nbTrash').textContent = nbTrashMode ? 'Voir mes notes' : 'Corbeille';
    $('nbNew').hidden = nbTrashMode;
    var q = normTxt($('nbSearch').value.trim()), list = $('nbList'); list.textContent = '';
    var items = notebook.filter(function(n){return n.deleted === nbTrashMode && (!q || normTxt(n.title+' '+n.text+' '+n.items.map(function(i){return i.text;}).join(' ')).indexOf(q)>=0);});
    items.sort(function(a,b){return Number(b.pinned)-Number(a.pinned) || b.updatedAt-a.updatedAt;});
    if (!items.length) list.appendChild(nbNode('p','notehist__empty',q?'Aucun résultat.':nbTrashMode?'La corbeille est vide.':'Créez votre première note avec le bouton + Note.'));
    items.forEach(function(n){
      var card = nbNode('article','nb-card'); card.dataset.color=n.color;
      var open = nbNode('button','nb-card__open'); open.type='button';
      open.appendChild(nbNode('strong','', (n.pinned?'📌 ':'')+(n.title.trim()||'Sans titre')));
      open.appendChild(nbNode('span','nb-preview',n.text.trim() || (n.items.length ? n.items.map(function(i){return (i.done?'✓ ':'○ ')+i.text;}).join(' · ') : 'Note vide')));
      if(n.items.length) open.appendChild(nbNode('small','',n.items.filter(function(i){return i.done;}).length+' / '+n.items.length+' cochés'));
      if(!nbTrashMode){open.addEventListener('click',function(){nbOpen(n);});card.appendChild(open);}
      else { var summary=nbNode('div','nb-card__open'); while(open.firstChild)summary.appendChild(open.firstChild);card.appendChild(summary);
        var actions=nbNode('div','nb-tools'), restore=nbNode('button','btn btn--ghost','Restaurer'), erase=nbNode('button','btn btn--ghost nb-danger','Supprimer définitivement');
        restore.type=erase.type='button'; restore.onclick=function(){n.deleted=false;nbPersist();renderNotebook();};
        erase.onclick=function(){if(window.confirm('Supprimer définitivement cette note ?')){notebook=notebook.filter(function(x){return x!==n;});nbPersist();renderNotebook();}};
        actions.appendChild(restore);actions.appendChild(erase);card.appendChild(actions);
      }list.appendChild(card);
    });
  }
  function nbOpen(n) {
    nbActive=n; $('nbBrowse').hidden=true; $('nbEditor').hidden=false; $('nbNew').hidden=true;
    $('nbTitle').value=n.title; $('nbText').value=n.text; $('nbColor').value=n.color; $('nbItemInput').value='';
    $('nbStatus').textContent=''; $('nbStatus').classList.remove('nb-danger'); nbReflectPin(); nbRenderItems();
  }
  function nbReflectPin(){ $('nbPin').textContent=nbActive.pinned?'Désépingler':'Épingler'; $('nbPin').setAttribute('aria-pressed',String(nbActive.pinned)); }
  function nbSave(){ if(!nbActive)return; nbActive.title=$('nbTitle').value; nbActive.text=$('nbText').value; nbActive.color=$('nbColor').value; nbActive.updatedAt=Date.now(); nbPersist(); }
  function nbRenderItems(){
    var list=$('nbItems');list.textContent='';
    nbActive.items.forEach(function(item,i){
      var row=nbNode('div','nb-item'), label=nbNode('label',''), check=nbNode('input',''), txt=nbNode('span','',item.text), del=nbNode('button','btn btn--ghost','×');
      check.type='checkbox';check.checked=item.done;check.onchange=function(){item.done=check.checked;nbSave();};
      del.type='button';del.setAttribute('aria-label','Retirer '+item.text);del.onclick=function(){nbActive.items.splice(i,1);nbSave();nbRenderItems();};
      label.appendChild(check);label.appendChild(txt);row.appendChild(label);row.appendChild(del);list.appendChild(row);
    });
  }
  function nbAddItem(){var text=$('nbItemInput').value.trim();if(!text || !nbActive)return;nbActive.items.push({text:text,done:false});$('nbItemInput').value='';nbSave();nbRenderItems();$('nbItemInput').focus();}
  function nbClose(){nbActive=null;renderNotebook();}
  function bindNotebook(){
    $('journalTab').onclick=function(){setNotebookMode(false);}; $('notebookTab').onclick=function(){setNotebookMode(true);};
    $('journalSearch').oninput=renderHistory; $('nbSearch').oninput=renderNotebook;
    $('nbTrash').onclick=function(){nbTrashMode=!nbTrashMode;renderNotebook();};
    $('nbNew').onclick=function(){var n={id:Storage.uid(),title:'',text:'',color:'neutral',pinned:false,updatedAt:Date.now(),deleted:false,items:[]};notebook.push(n);nbOpen(n);nbPersist();$('nbTitle').focus();};
    $('nbBack').onclick=nbClose; $('nbTitle').oninput=nbSave;$('nbText').oninput=nbSave;$('nbColor').onchange=nbSave;
    $('nbPin').onclick=function(){nbActive.pinned=!nbActive.pinned;nbSave();nbReflectPin();};
    $('nbAddItem').onclick=nbAddItem;$('nbItemInput').onkeydown=function(e){if(e.key==='Enter'){e.preventDefault();nbAddItem();}};
    $('nbDelete').onclick=function(){nbActive.deleted=true;nbSave();nbClose();showToast('Note placée dans la corbeille.');};
  }

  // ===== Thème (clair / sombre / système) =====
  function systemPrefersDark() {
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  }
  function effectiveTheme() {
    var t = settings.theme || 'system';
    return (t === 'dark' || (t === 'system' && systemPrefersDark())) ? 'dark' : 'light';
  }
  function applyTheme() {
    var eff = effectiveTheme();
    document.documentElement.setAttribute('data-theme', eff);
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', eff === 'dark' ? '#141220' : '#6555E8');
    var btns = document.querySelectorAll('[data-theme-opt]');
    Array.prototype.forEach.call(btns, function (b) {
      var on = b.getAttribute('data-theme-opt') === (settings.theme || 'system');
      b.classList.toggle('is-active', on);
      b.setAttribute('aria-checked', on ? 'true' : 'false');
    });
  }
  function setTheme(t) {
    settings.theme = t;
    Storage.saveSettings(settings);
    applyTheme();
  }

  // ===== Fond d'écran (galerie zen) =====
  var BG_COUNT = 34;
  var randomBgId = '';           // fond tiré au hasard pour la session en cours
  function bgUrl(id) { return 'assets/backgrounds/' + id + '.jpg'; }
  function bgThumbUrl(id) { return 'assets/backgrounds/thumb/' + id + '.jpg'; }

  function pickRandomBg() {
    return 'bg-' + pad(1 + Math.floor(Math.random() * BG_COUNT));
  }

  // Convertit le réglage en image à afficher : '' = aucun, 'random' = tirage de
  // session, 'bg-XX' = fond épinglé.
  function currentBgId() {
    var b = settings.bg || '';
    if (b === 'random') {
      if (!randomBgId) randomBgId = pickRandomBg();
      return randomBgId;
    }
    if (/^bg-\d+$/.test(b)) return b;
    return '';
  }

  function applyBackground() {
    var id = currentBgId();
    if (id) {
      bgLayer.style.backgroundImage = 'url("' + bgUrl(id) + '")';
      document.body.classList.add('has-bg');
    } else {
      bgLayer.style.backgroundImage = 'none';
      document.body.classList.remove('has-bg');
    }
    markActiveBgTile();
  }

  function setBackground(id) {
    settings.bg = id || '';
    if (id === 'random') randomBgId = pickRandomBg(); // nouveau tirage immédiat à la sélection
    Storage.saveSettings(settings);
    applyBackground();
  }

  function markActiveBgTile() {
    if (!bgGrid) return;
    var tiles = bgGrid.querySelectorAll('.bgtile');
    Array.prototype.forEach.call(tiles, function (t) {
      t.classList.toggle('is-active', (t.getAttribute('data-bg') || '') === (settings.bg || ''));
    });
  }

  function buildBgGrid() {
    if (!bgGrid) return;
    var check = '<span class="bgtile__check">' + ICON_CHECK + '</span>';
    var html = '<button class="bgtile bgtile--random" type="button" data-bg="random" aria-label="Fond aléatoire">' +
               ICON_SHUFFLE + '<span class="bgtile__label">Aléatoire</span>' + check + '</button>';
    html += '<button class="bgtile bgtile--none" type="button" data-bg="" aria-label="Aucun fond">Aucun' + check + '</button>';
    for (var i = 1; i <= BG_COUNT; i++) {
      var id = 'bg-' + pad(i);
      html += '<button class="bgtile" type="button" data-bg="' + id + '" aria-label="Fond ' + i + '"' +
              ' style="background-image:url(\'' + bgThumbUrl(id) + '\')">' + check + '</button>';
    }
    bgGrid.innerHTML = html;
    bgGrid.addEventListener('click', function (e) {
      var tile = e.target.closest('.bgtile');
      if (!tile) return;
      setBackground(tile.getAttribute('data-bg') || '');
    });
    markActiveBgTile();
  }

  // ===== Réglages (feuille) =====
  function openSettings() {
    backdrop.hidden = false;
    settingsSheet.hidden = false;
    void settingsSheet.offsetWidth;
    backdrop.classList.add('is-open');
    settingsSheet.classList.add('is-open');
  }
  function closeSettings() {
    backdrop.classList.remove('is-open');
    settingsSheet.classList.remove('is-open');
    window.setTimeout(function () {
      backdrop.hidden = true;
      settingsSheet.hidden = true;
    }, 240);
  }

  function openSnoozeSheet(id) {
    snoozeTargetId = id;
    backdrop.hidden = false;
    snoozeSheet.hidden = false;
    void snoozeSheet.offsetWidth;
    backdrop.classList.add('is-open');
    snoozeSheet.classList.add('is-open');
  }
  function closeSnoozeSheet() {
    backdrop.classList.remove('is-open');
    snoozeSheet.classList.remove('is-open');
    window.setTimeout(function () {
      backdrop.hidden = true;
      snoozeSheet.hidden = true;
      snoozeTargetId = null;
    }, 240);
  }

  // ===== Export / import / effacement =====
  function exportData() {
    flushNote(); flushIntention();
    var payload = {
      app: 'mon-agenda', version: 2, exportedAt: new Date().toISOString(),
      tasks: tasks, notes: notes, notebook: notebook, intentions: intentions, moods: moods, settings: settings
    };
    var blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'mon-agenda-sauvegarde-' + localDateStr(new Date()) + '.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    showToast('Sauvegarde exportée.');
  }

  function sanitizeTasks(arr) {
    return arr.filter(function (t) { return t && typeof t.title === 'string'; })
      .map(function (t) {
        return {
          id: t.id || Storage.uid(),
          title: String(t.title),
          note: typeof t.note === 'string' ? t.note : '',
          date: typeof t.date === 'string' ? t.date : '',
          time: typeof t.time === 'string' ? t.time : '',
          prio: (t.prio === 'low' || t.prio === 'high') ? t.prio : 'normal',
          cat: (typeof t.cat === 'string' && catById(t.cat)) ? t.cat : '',
          subtasks: Array.isArray(t.subtasks)
            ? t.subtasks.map(function (s) {
                return { id: (s && s.id) || Storage.uid(), title: String((s && s.title) || ''), done: !!(s && s.done) };
              }).filter(function (s) { return s.title; })
            : [],
          lead: parseInt(t.lead, 10) || 0,
          repeat: (t.repeat === 'daily' || t.repeat === 'weekly' || t.repeat === 'monthly') ? t.repeat : 'none',
          done: !!t.done,
          createdAt: t.createdAt || Date.now(),
          completedAt: t.completedAt || null,
          notified: !!t.notified,
          snoozeUntil: (typeof t.snoozeUntil === 'number') ? t.snoozeUntil : null
        };
      });
  }

  function importData(file) {
    var reader = new FileReader();
    reader.onload = function () {
      var data;
      try { data = JSON.parse(reader.result); }
      catch (e) { showToast('Fichier illisible.'); return; }
      if (!data || typeof data !== 'object') { showToast('Sauvegarde invalide.'); return; }
      var hasTasks = Array.isArray(data.tasks);
      var hasNotes = data.notes && typeof data.notes === 'object' && !Array.isArray(data.notes);
      var hasIntentions = data.intentions && typeof data.intentions === 'object' && !Array.isArray(data.intentions);
      var hasMoods = data.moods && typeof data.moods === 'object' && !Array.isArray(data.moods);
      var hasNotebook = Array.isArray(data.notebook);
      if (!hasTasks && !hasNotes && !hasIntentions && !hasMoods && !hasNotebook) { showToast('Aucune donnée reconnue.'); return; }
      if (!window.confirm('Remplacer vos tâches et notes actuelles par cette sauvegarde ?')) return;

      flushNote(); flushIntention();
      if (hasNotebook) { notebook = sanitizeNotebook(data.notebook); nbActive = null; nbTrashMode = false; Storage.saveNotebook(notebook); renderNotebook(); }
      if (hasTasks) tasks = sanitizeTasks(data.tasks);
      if (hasNotes) notes = data.notes;
      if (hasIntentions) intentions = data.intentions;
      if (hasMoods) moods = data.moods;
      if (data.settings && typeof data.settings === 'object') {
        var s = data.settings;
        settings = {
          theme: s.theme || 'system',
          bg: (typeof s.bg === 'string') ? s.bg : 'random',
          music: (typeof s.music === 'boolean') ? s.music : true,
          track: (s.track === '2') ? '2' : '1',
          volume: (typeof s.volume === 'number') ? s.volume : 0.4,
          haptics: (typeof s.haptics === 'boolean') ? s.haptics : true,
          morningSummary: (typeof s.morningSummary === 'boolean') ? s.morningSummary : true
        };
      }
      Storage.saveAll(tasks);
      Storage.saveNotes(notes);
      Storage.saveIntentions(intentions);
      Storage.saveMoods(moods);
      Storage.saveSettings(settings);
      Reminders.clearAll();
      scheduleAll();
      applyTheme();
      applyBackground();
      applyAudioConfig();
      if (settings.music) playMusic();
      reflectHaptics();
      reflectMorning();
      selectedDate = localDateStr(new Date());
      closeSettings();
      renderCurrent();
      showToast('Données importées.');
    };
    reader.onerror = function () { showToast('Lecture impossible.'); };
    reader.readAsText(file);
  }

  function clearData() {
    if (!window.confirm('Effacer définitivement toutes les tâches et toutes les notes ?')) return;
    flushNote(); flushIntention();
    tasks = [];
    notebook = []; nbActive = null; nbTrashMode = false; Storage.saveNotebook(notebook); renderNotebook();
    notes = {};
    intentions = {};
    moods = {};
    Storage.saveAll(tasks);
    Storage.saveNotes(notes);
    Storage.saveIntentions(intentions);
    Storage.saveMoods(moods);
    Reminders.clearAll();
    selectedDate = localDateStr(new Date());
    closeSettings();
    renderCurrent();
    showToast('Données effacées.');
  }

  // ===== Fond sonore =====
  var TRACKS = {
    '1': 'assets/audio/eveil-du-coeur-1.mp3',
    '2': 'assets/audio/eveil-du-coeur-2.mp3'
  };
  var musicResumeArmed = false;

  function musicVol() {
    return (typeof settings.volume === 'number') ? settings.volume : 0.4;
  }

  function applyAudioConfig() {
    if (!bgMusic) return;
    var track = (settings.track === '2') ? '2' : '1';
    if (bgMusic.getAttribute('data-track') !== track) {
      bgMusic.src = TRACKS[track];
      bgMusic.setAttribute('data-track', track);
    }
    bgMusic.loop = true;
    bgMusic.volume = musicVol();
    reflectMusicUI();
  }

  function playMusic() {
    if (!bgMusic) return;
    applyAudioConfig();
    var p = bgMusic.play();
    if (p && p.catch) p.catch(function () { /* lecture bloquée tant qu'aucune interaction */ });
  }

  function pauseMusic() {
    if (bgMusic) bgMusic.pause();
  }

  function toggleMusic() {
    settings.music = !settings.music;
    Storage.saveSettings(settings);
    if (settings.music) playMusic(); else pauseMusic();
    reflectMusicUI();
  }

  function setTrack(id) {
    settings.track = (id === '2') ? '2' : '1';
    Storage.saveSettings(settings);
    bgMusic.src = TRACKS[settings.track];
    bgMusic.setAttribute('data-track', settings.track);
    bgMusic.loop = true;
    bgMusic.volume = musicVol();
    if (settings.music) {
      var p = bgMusic.play();
      if (p && p.catch) p.catch(function () {});
    }
    reflectMusicUI();
  }

  function setVolume(v) {
    settings.volume = Math.max(0, Math.min(1, v));
    Storage.saveSettings(settings);
    if (bgMusic) bgMusic.volume = settings.volume;
    reflectMusicUI();
  }

  function reflectMusicUI() {
    var on = !!settings.music;
    if (musicBtn) {
      musicBtn.innerHTML = on ? ICON_SOUND_ON : ICON_SOUND_OFF;
      musicBtn.classList.toggle('is-active', on);
      musicBtn.setAttribute('aria-label', on ? 'Couper le fond sonore' : 'Activer le fond sonore');
      musicBtn.setAttribute('title', on ? 'Couper le fond sonore' : 'Activer le fond sonore');
    }
    if (musicToggle) {
      var mb = musicToggle.querySelectorAll('.seg__btn');
      Array.prototype.forEach.call(mb, function (b) {
        var active = (b.getAttribute('data-music') === (on ? 'on' : 'off'));
        b.classList.toggle('is-active', active);
        b.setAttribute('aria-checked', active ? 'true' : 'false');
      });
    }
    if (trackPicker) {
      var tb = trackPicker.querySelectorAll('.catpill');
      Array.prototype.forEach.call(tb, function (b) {
        var active = (b.getAttribute('data-track') === (settings.track === '2' ? '2' : '1'));
        b.classList.toggle('is-active', active);
        b.setAttribute('aria-checked', active ? 'true' : 'false');
      });
    }
    if (musicVolume) musicVolume.value = String(Math.round(musicVol() * 100));
  }

  // Les navigateurs bloquent le son tant qu'il n'y a pas eu d'interaction :
  // on arme une reprise au premier geste de l'utilisateur si la musique est activée.
  function setupMusicResume() {
    if (musicResumeArmed) return;
    musicResumeArmed = true;
    var resume = function () {
      document.removeEventListener('pointerdown', resume);
      document.removeEventListener('keydown', resume);
      document.removeEventListener('touchstart', resume);
      if (settings.music) {
        var p = bgMusic.play();
        if (p && p.catch) p.catch(function () {});
      }
    };
    document.addEventListener('pointerdown', resume);
    document.addEventListener('keydown', resume);
    document.addEventListener('touchstart', resume);
  }

  // ===== Retour haptique (vibration) =====
  // Natif : plugin Capacitor Haptics (ajoute aussi la permission VIBRATE).
  // Web : API navigator.vibrate (Android/Chrome ; ignorée sur iOS Safari).
  function hapticTap(kind) {
    if (!settings.haptics) return;
    try {
      var Cap = window.Capacitor;
      if (Cap && Cap.Plugins && Cap.Plugins.Haptics) {
        var H = Cap.Plugins.Haptics;
        if (kind === 'success' && H.notification) { H.notification({ type: 'SUCCESS' }); return; }
        if (H.impact) { H.impact({ style: (kind === 'success') ? 'MEDIUM' : 'LIGHT' }); return; }
      }
    } catch (e) { /* ignoré */ }
    try {
      if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
        navigator.vibrate(kind === 'success' ? [12, 40, 18] : 12);
      }
    } catch (e) { /* ignoré */ }
  }

  function reflectHaptics() {
    if (!hapticToggle) return;
    var on = !!settings.haptics;
    var btns = hapticToggle.querySelectorAll('.seg__btn');
    Array.prototype.forEach.call(btns, function (b) {
      var active = (b.getAttribute('data-haptic') === (on ? 'on' : 'off'));
      b.classList.toggle('is-active', active);
      b.setAttribute('aria-checked', active ? 'true' : 'false');
    });
  }
  function setHaptics(on) {
    settings.haptics = !!on;
    Storage.saveSettings(settings);
    reflectHaptics();
    if (on) hapticTap('light'); // petit aperçu quand on active
  }

  function reflectMorning() {
    if (!morningToggle) return;
    var on = !!settings.morningSummary;
    var btns = morningToggle.querySelectorAll('.seg__btn');
    Array.prototype.forEach.call(btns, function (b) {
      var active = (b.getAttribute('data-morning') === (on ? 'on' : 'off'));
      b.classList.toggle('is-active', active);
      b.setAttribute('aria-checked', active ? 'true' : 'false');
    });
  }
  function setMorning(on) {
    settings.morningSummary = !!on;
    Storage.saveSettings(settings);
    reflectMorning();
    scheduleMorningSummary();
    showToast(on ? 'Résumé du matin activé.' : 'Résumé du matin désactivé.');
  }

  // ===== Respiration guidée =====
  // Cycle apaisant : inspirez 4 s, retenez 2 s, expirez 6 s (expiration longue).
  var BREATH_PHASES = [
    { label: 'Inspirez', dur: 4000, big: true },
    { label: 'Retenez', dur: 2000, big: true },
    { label: 'Expirez', dur: 6000, big: false }
  ];

  function breathStep(i) {
    var p = BREATH_PHASES[i % BREATH_PHASES.length];
    if (breathLabel) breathLabel.textContent = p.label;
    if (breathCircle) {
      breathCircle.style.transitionDuration = p.dur + 'ms';
      breathCircle.style.transform = 'scale(' + (p.big ? 1 : 0.5) + ')';
    }
    breathTimer = window.setTimeout(function () { breathStep(i + 1); }, p.dur);
  }

  function openBreath() {
    if (!breathOverlay) return;
    breathOverlay.hidden = false;
    document.body.classList.add('breathing');
    if (breathCircle) {
      breathCircle.style.transitionDuration = '0ms';
      breathCircle.style.transform = 'scale(0.5)';
    }
    if (breathLabel) breathLabel.textContent = 'Prêt…';
    if (breathTimer) window.clearTimeout(breathTimer);
    breathTimer = window.setTimeout(function () { breathStep(0); }, 700);
  }

  function closeBreath() {
    if (breathTimer) { window.clearTimeout(breathTimer); breathTimer = null; }
    document.body.classList.remove('breathing');
    if (breathOverlay) breathOverlay.hidden = true;
  }

  // ===== Calendrier =====
  var MONTHS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin',
    'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];

  function startOfMonth(d) { return new Date(d.getFullYear(), d.getMonth(), 1); }

  function dayHasActiveTask(dateStr) {
    for (var i = 0; i < tasks.length; i++) {
      if (!tasks[i].done && tasks[i].date === dateStr) return true;
    }
    return false;
  }
  function dayHasNote(dateStr) {
    return !!(notes[dateStr] && notes[dateStr].text && notes[dateStr].text.trim() !== '');
  }

  function renderCalendar() {
    renderHeroDate();
    setHeroSummaryTasks();

    monthLabel.textContent = capitalize(MONTHS[calMonth.getMonth()]) + ' ' + calMonth.getFullYear();

    var first = startOfMonth(calMonth);
    var firstWeekday = (first.getDay() + 6) % 7; // lundi = 0
    var gridStart = new Date(first);
    gridStart.setDate(first.getDate() - firstWeekday);

    var todayStr = localDateStr(new Date());
    var monthIdx = calMonth.getMonth();
    var html = '';
    for (var i = 0; i < 42; i++) {
      var d = new Date(gridStart);
      d.setDate(gridStart.getDate() + i);
      var ds = localDateStr(d);
      var cls = 'cal__cell';
      if (d.getMonth() !== monthIdx) cls += ' is-out';
      if (ds === todayStr) cls += ' is-today';
      if (ds === calSelected) cls += ' is-selected';
      var dots = '';
      if (dayHasActiveTask(ds)) dots += '<span class="cal__dot cal__dot--task"></span>';
      if (dayHasNote(ds)) dots += '<span class="cal__dot cal__dot--note"></span>';
      html += '<button class="' + cls + '" type="button" data-day="' + ds + '">' +
                '<span class="cal__num">' + d.getDate() + '</span>' +
                '<span class="cal__dots">' + dots + '</span>' +
              '</button>';
    }
    calGrid.innerHTML = html;
    renderCalDetail();
  }

  function renderCalDetail() {
    var dayTasks = tasks.filter(function (t) { return t.date === calSelected; });
    dayTasks.sort(function (a, b) {
      if (!!a.done !== !!b.done) return a.done ? 1 : -1;
      return (dueAtMs(a) || 0) - (dueAtMs(b) || 0);
    });

    var head = '<div class="caldetail__head">' +
      '<h3 class="caldetail__title">' + escapeHtml(capitalize(fullDateLabel(calSelected))) + '</h3>' +
      '<button class="btn btn--primary caldetail__add" id="calAdd" type="button">+ Tâche</button></div>';

    var body = dayTasks.length
      ? dayTasks.map(taskHtml).join('')
      : '<p class="caldetail__empty">Aucune tâche ce jour-là.</p>';

    var noteText = dayHasNote(calSelected)
      ? '<p class="caldetail__note-text">' +
          escapeHtml(notes[calSelected].text.replace(/\s+/g, ' ').trim().slice(0, 160)) + '</p>'
      : '<p class="caldetail__note-text" style="color:var(--faint)">Ajouter une note pour cette journée…</p>';
    var note = '<button class="caldetail__note" id="calNote" type="button">' +
      '<p class="caldetail__note-label">Note du jour</p>' + noteText + '</button>';

    calDetail.innerHTML = head + body + note;

    var addBtn = document.getElementById('calAdd');
    if (addBtn) addBtn.addEventListener('click', function () { openSheet(null, '', calSelected); });
    var noteBtn = document.getElementById('calNote');
    if (noteBtn) noteBtn.addEventListener('click', function () { openNoteForDay(calSelected); });
  }

  function openNoteForDay(dateStr) {
    flushNote(); flushIntention();
    selectedDate = dateStr;
    setNotebookMode(false);
    switchView('notes');
  }

  function shiftMonth(delta) {
    calMonth = new Date(calMonth.getFullYear(), calMonth.getMonth() + delta, 1);
    renderCalendar();
  }

  // ===== Branchement des événements =====
  function bind() {
    // Ajout rapide
    $('quickAdd').addEventListener('click', quickAdd);
    quickInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); quickAdd(); }
    });
    $('quickDetails').addEventListener('click', function () {
      var v = quickInput.value.trim();
      quickInput.value = '';
      openSheet(null, v);
    });

    // FAB
    $('fab').addEventListener('click', function () { openSheet(null, ''); });

    // Bascule de vue
    var viewBtns = document.querySelectorAll('.view');
    Array.prototype.forEach.call(viewBtns, function (b) {
      b.addEventListener('click', function () { switchView(b.getAttribute('data-view')); });
    });

    // Bloc-notes
    bindNotebook();
    noteTextEl.addEventListener('input', scheduleNoteSave);
    noteTextEl.addEventListener('blur', flushNote);
    if (intentionInput) {
      intentionInput.addEventListener('input', scheduleIntentionSave);
      intentionInput.addEventListener('blur', flushIntention);
    }
    if (moodPicker) moodPicker.addEventListener('click', function (e) {
      var b = e.target.closest('.mood__btn');
      if (b) setMood(parseInt(b.getAttribute('data-mood'), 10));
    });
    $('dayPrev').addEventListener('click', function () { gotoDay(shiftDay(selectedDate, -1)); });
    $('dayNext').addEventListener('click', function () { gotoDay(shiftDay(selectedDate, 1)); });
    $('dayToday').addEventListener('click', function () { gotoDay(localDateStr(new Date())); });
    dayInput.addEventListener('change', function () {
      if (dayInput.value) gotoDay(dayInput.value);
    });
    noteHistory.addEventListener('click', function (e) {
      var card = e.target.closest('.notecard');
      if (card) gotoDay(card.getAttribute('data-day'));
    });

    // Filtres
    var filterBtns = document.querySelectorAll('.filter');
    Array.prototype.forEach.call(filterBtns, function (b) {
      b.addEventListener('click', function () {
        Array.prototype.forEach.call(filterBtns, function (x) { x.classList.remove('is-active'); });
        b.classList.add('is-active');
        filter = b.getAttribute('data-filter');
        render();
      });
    });

    // Filtres par catégorie (délégation, contenu reconstruit dynamiquement)
    if (catFilters) {
      catFilters.addEventListener('click', function (e) {
        var b = e.target.closest('.catfilter');
        if (!b) return;
        catFilter = b.getAttribute('data-cat') || '';
        render();
      });
    }

    // Sélecteur de catégorie dans la feuille
    if (catPicker) {
      catPicker.addEventListener('click', function (e) {
        var b = e.target.closest('.catpill');
        if (!b) return;
        setCat(b.getAttribute('data-cat') || '');
      });
    }

    // Fond sonore
    if (musicBtn) musicBtn.addEventListener('click', toggleMusic);
    if (musicToggle) {
      musicToggle.addEventListener('click', function (e) {
        var b = e.target.closest('.seg__btn');
        if (!b) return;
        var want = (b.getAttribute('data-music') === 'on');
        if (want !== !!settings.music) toggleMusic();
      });
    }
    if (trackPicker) {
      trackPicker.addEventListener('click', function (e) {
        var b = e.target.closest('.catpill');
        if (!b) return;
        setTrack(b.getAttribute('data-track') || '1');
      });
    }
    if (musicVolume) {
      musicVolume.addEventListener('input', function () {
        setVolume((parseInt(musicVolume.value, 10) || 0) / 100);
      });
    }
    if (hapticToggle) hapticToggle.addEventListener('click', function (e) {
      var b = e.target.closest('.seg__btn');
      if (b) setHaptics(b.getAttribute('data-haptic') === 'on');
    });
    if (morningToggle) morningToggle.addEventListener('click', function (e) {
      var b = e.target.closest('.seg__btn');
      if (b) setMorning(b.getAttribute('data-morning') === 'on');
    });

    // Recherche
    if (searchBtn) {
      searchBtn.addEventListener('click', function () {
        var show = searchBar.hidden;
        searchBar.hidden = !show;
        searchBtn.classList.toggle('is-active', show);
        if (show) {
          searchInput.focus();
        } else {
          searchInput.value = '';
          searchQuery = '';
          render();
        }
      });
      searchInput.addEventListener('input', function () {
        searchQuery = searchInput.value;
        render();
      });
      searchClear.addEventListener('click', function () {
        searchInput.value = '';
        searchQuery = '';
        searchInput.focus();
        render();
      });
    }

    // Liste + calendrier : délégation (cocher ou ouvrir)
    listEl.addEventListener('click', handleTaskClick);
    calDetail.addEventListener('click', handleTaskClick);

    // Calendrier : navigation
    $('monthPrev').addEventListener('click', function () { shiftMonth(-1); });
    $('monthNext').addEventListener('click', function () { shiftMonth(1); });
    monthLabel.addEventListener('click', function () {
      calMonth = startOfMonth(new Date());
      calSelected = localDateStr(new Date());
      renderCalendar();
    });
    calGrid.addEventListener('click', function (e) {
      var cell = e.target.closest('.cal__cell');
      if (!cell) return;
      calSelected = cell.getAttribute('data-day');
      var d = new Date(calSelected + 'T00:00:00');
      if (d.getMonth() !== calMonth.getMonth() || d.getFullYear() !== calMonth.getFullYear()) {
        calMonth = startOfMonth(d);
      }
      renderCalendar();
    });

    // Feuille (tâche)
    $('sheetSave').addEventListener('click', saveSheet);
    $('sheetCancel').addEventListener('click', closeSheet);
    $('sheetClose').addEventListener('click', closeSheet);
    sheetDelete.addEventListener('click', deleteCurrent);
    backdrop.addEventListener('click', function () {
      if (!sheet.hidden) closeSheet();
      if (!settingsSheet.hidden) closeSettings();
      if (!snoozeSheet.hidden) closeSnoozeSheet();
    });

    // Feuille de report de rappel (snooze)
    if (snoozeSheet) snoozeSheet.addEventListener('click', function (e) {
      var b = e.target.closest('.snooze-opt');
      if (!b || !snoozeTargetId) return;
      var ms = snoozePresetMs(b.getAttribute('data-snooze'));
      var id = snoozeTargetId;
      closeSnoozeSheet();
      applySnooze(id, ms);
    });
    if (snoozeCancel) snoozeCancel.addEventListener('click', closeSnoozeSheet);

    // Respiration guidée
    if (breathBtn) breathBtn.addEventListener('click', openBreath);
    if (breathClose) breathClose.addEventListener('click', closeBreath);
    if (breathOverlay) breathOverlay.addEventListener('click', function (e) {
      if (e.target === breathOverlay) closeBreath(); // toucher le fond ferme
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && breathOverlay && !breathOverlay.hidden) closeBreath();
    });

    var segBtns = sheet.querySelectorAll('.seg__btn');
    Array.prototype.forEach.call(segBtns, function (b) {
      b.addEventListener('click', function () { setPrio(b.getAttribute('data-prio')); });
    });

    // Réglages
    $('settingsBtn').addEventListener('click', openSettings);
    $('settingsClose').addEventListener('click', closeSettings);
    $('settingsDone').addEventListener('click', closeSettings);
    var themeBtns = document.querySelectorAll('[data-theme-opt]');
    Array.prototype.forEach.call(themeBtns, function (b) {
      b.addEventListener('click', function () { setTheme(b.getAttribute('data-theme-opt')); });
    });
    $('exportBtn').addEventListener('click', exportData);
    $('importBtn').addEventListener('click', function () { $('importFile').click(); });
    $('importFile').addEventListener('change', function (e) {
      var f = e.target.files && e.target.files[0];
      if (f) importData(f);
      e.target.value = '';
    });
    $('clearBtn').addEventListener('click', clearData);

    // Suit le thème du système quand l'option « Système » est choisie
    var mq = window.matchMedia('(prefers-color-scheme: dark)');
    var onSchemeChange = function () { if ((settings.theme || 'system') === 'system') applyTheme(); };
    if (mq.addEventListener) mq.addEventListener('change', onSchemeChange);
    else if (mq.addListener) mq.addListener(onSchemeChange);

    // Échap ferme la feuille ouverte
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return;
      if (!sheet.hidden) closeSheet();
      else if (!settingsSheet.hidden) closeSettings();
    });
    fTitle.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); saveSheet(); }
    });

    // Date express
    if (dateQuick) dateQuick.addEventListener('click', function (e) {
      var b = e.target.closest('.dquick__btn');
      if (b) setQuickDate(b.getAttribute('data-quick'));
    });
    if (fDate) fDate.addEventListener('change', reflectQuickDate);

    // Éditeur de sous-tâches
    if (subAdd) subAdd.addEventListener('click', addSubFromInput);
    if (subInput) subInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); addSubFromInput(); }
    });
    if (subList) subList.addEventListener('click', function (e) {
      var tog = e.target.closest('[data-draft-toggle]');
      if (tog) { draftToggleSub(tog.getAttribute('data-draft-toggle')); return; }
      var del = e.target.closest('[data-draft-del]');
      if (del) { draftDelSub(del.getAttribute('data-draft-del')); }
    });

    // Bouton d'action du toast (ex. Annuler la suppression)
    if (toastEl) toastEl.addEventListener('click', function (e) {
      if (e.target.closest('.toast__action') && toastAction) {
        var fn = toastAction;
        toastAction = null;
        hideToastNow();
        fn();
      }
    });

    // Sauvegarde des notes + vérification des échéances au changement de visibilité
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) {
        flushNote();
        flushIntention();
      } else {
        if (view === 'tasks') render();
        checkDue();
      }
    });
    window.addEventListener('beforeunload', function () { flushNote(); flushIntention(); });

    // Installation (PWA)
    window.addEventListener('beforeinstallprompt', function (e) {
      e.preventDefault();
      deferredInstall = e;
      $('installBtn').hidden = false;
    });
    $('installBtn').addEventListener('click', function () {
      if (!deferredInstall) return;
      deferredInstall.prompt();
      deferredInstall.userChoice.finally(function () {
        deferredInstall = null;
        $('installBtn').hidden = true;
      });
    });
    window.addEventListener('appinstalled', function () {
      $('installBtn').hidden = true;
    });
  }

  // ===== Service worker (hors-ligne) =====
  function registerSW() {
    // Inutile dans l'APK natif (les fichiers sont déjà embarqués) — on évite toute interférence.
    if (window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' && window.Capacitor.isNativePlatform()) return;
    if (!('serviceWorker' in navigator) || location.protocol.indexOf('http') !== 0) return;
    navigator.serviceWorker.register('service-worker.js').catch(function () { /* ignoré */ });
  }

  // ===== Démarrage =====
  function init() {
    selectedDate = localDateStr(new Date());
    calMonth = startOfMonth(new Date());
    calSelected = localDateStr(new Date());
    applyTheme();
    randomBgId = pickRandomBg();
    buildBgGrid();
    applyBackground();
    applyAudioConfig();
    setupMusicResume();
    reflectHaptics();
    reflectMorning();
    if (Reminders.onAction) Reminders.onAction(handleNotificationAction);
    bind();
    renderNotes(); // prépare l'éditeur et l'historique (vue cachée au départ)
    render();      // la vue Tâches est affichée au démarrage
    scheduleAll();
    checkDue();
    window.setInterval(checkDue, 30000); // re-vérifie toutes les 30 s
    registerSW();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
