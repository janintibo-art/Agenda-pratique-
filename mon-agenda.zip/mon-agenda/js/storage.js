/* Stockage local des tâches (aucune donnée envoyée sur internet). */
var Storage = (function () {
  var KEY = 'agenda.tasks.v1';
  var NOTES_KEY = 'agenda.notes.v1';
  var SETTINGS_KEY = 'agenda.settings.v1';

  function load() {
    try {
      var raw = localStorage.getItem(KEY);
      var data = raw ? JSON.parse(raw) : [];
      return Array.isArray(data) ? data : [];
    } catch (e) {
      return [];
    }
  }

  function saveAll(tasks) {
    try {
      localStorage.setItem(KEY, JSON.stringify(tasks));
    } catch (e) {
      /* quota dépassé ou stockage indisponible : on ignore silencieusement */
    }
  }

  function uid() {
    return 't_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  // --- Notes quotidiennes : objet { 'AAAA-MM-JJ': { text, updatedAt } } ---
  function loadNotes() {
    try {
      var raw = localStorage.getItem(NOTES_KEY);
      var data = raw ? JSON.parse(raw) : {};
      return (data && typeof data === 'object' && !Array.isArray(data)) ? data : {};
    } catch (e) {
      return {};
    }
  }

  function saveNotes(obj) {
    try {
      localStorage.setItem(NOTES_KEY, JSON.stringify(obj));
    } catch (e) { /* ignoré */ }
  }

  // --- Réglages : { theme: 'system' | 'light' | 'dark' } ---
  function loadSettings() {
    try {
      var raw = localStorage.getItem(SETTINGS_KEY);
      var data = raw ? JSON.parse(raw) : {};
      if (!data || typeof data !== 'object') data = {};
    } catch (e) { data = {}; }
    if (!data.theme) data.theme = 'system';
    return data;
  }

  function saveSettings(obj) {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(obj));
    } catch (e) { /* ignoré */ }
  }

  return {
    load: load, saveAll: saveAll, uid: uid,
    loadNotes: loadNotes, saveNotes: saveNotes,
    loadSettings: loadSettings, saveSettings: saveSettings
  };
})();
