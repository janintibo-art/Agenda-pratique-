/* Stockage local des tâches (aucune donnée envoyée sur internet). */
var Storage = (function () {
  var KEY = 'agenda.tasks.v1';
  var NOTES_KEY = 'agenda.notes.v1';
  var NOTEBOOK_KEY = 'agenda.notebook.v1';
  var INTENTIONS_KEY = 'agenda.intentions.v1';
  var MOODS_KEY = 'agenda.moods.v1';
  var SETTINGS_KEY = 'agenda.settings.v1';

  function load() {
    try {
      var raw = localStorage.getItem(KEY);
      var data = raw ? JSON.parse(raw) : [];
      return Array.isArray(data) ? data : [];
    } catch (e) {
      return [];
    }
  }

  function saveAll(tasks) {
    try {
      localStorage.setItem(KEY, JSON.stringify(tasks));
    } catch (e) {
      /* quota dépassé ou stockage indisponible : on ignore silencieusement */
    }
  }

  function uid() {
    return 't_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  // --- Notes quotidiennes : objet { 'AAAA-MM-JJ': { text, updatedAt } } ---
  function loadNotes() {
    try {
      var raw = localStorage.getItem(NOTES_KEY);
      var data = raw ? JSON.parse(raw) : {};
      return (data && typeof data === 'object' && !Array.isArray(data)) ? data : {};
    } catch (e) {
      return {};
    }
  }

  function saveNotes(obj) {
    try {
      localStorage.setItem(NOTES_KEY, JSON.stringify(obj));
      return true;
    } catch (e) { return false; }
  }

  function loadNotebook() {
    try { var data = JSON.parse(localStorage.getItem(NOTEBOOK_KEY) || '[]'); return Array.isArray(data) ? data : []; }
    catch (e) { return []; }
  }
  function saveNotebook(data) {
    try { localStorage.setItem(NOTEBOOK_KEY, JSON.stringify(data)); return true; }
    catch (e) { return false; }
  }

  // --- Intentions quotidiennes : objet { 'AAAA-MM-JJ': { text, updatedAt } } ---
  function loadIntentions() {
    try {
      var raw = localStorage.getItem(INTENTIONS_KEY);
      var data = raw ? JSON.parse(raw) : {};
      return (data && typeof data === 'object' && !Array.isArray(data)) ? data : {};
    } catch (e) {
      return {};
    }
  }

  function saveIntentions(obj) {
    try {
      localStorage.setItem(INTENTIONS_KEY, JSON.stringify(obj));
    } catch (e) { /* ignoré */ }
  }

  // --- Humeurs quotidiennes : objet { 'AAAA-MM-JJ': { level: 1..5, updatedAt } } ---
  function loadMoods() {
    try {
      var raw = localStorage.getItem(MOODS_KEY);
      var data = raw ? JSON.parse(raw) : {};
      return (data && typeof data === 'object' && !Array.isArray(data)) ? data : {};
    } catch (e) {
      return {};
    }
  }

  function saveMoods(obj) {
    try {
      localStorage.setItem(MOODS_KEY, JSON.stringify(obj));
    } catch (e) { /* ignoré */ }
  }

  // --- Réglages : { theme: 'system' | 'light' | 'dark' } ---
  function loadSettings() {
    try {
      var raw = localStorage.getItem(SETTINGS_KEY);
      var data = raw ? JSON.parse(raw) : {};
      if (!data || typeof data !== 'object') data = {};
    } catch (e) { data = {}; }
    if (!data.theme) data.theme = 'system';
    if (typeof data.bg !== 'string') data.bg = 'random'; // fond zen tiré au hasard à chaque ouverture
    if (typeof data.music !== 'boolean') data.music = true; // fond sonore activé par défaut
    if (data.track !== '1' && data.track !== '2') data.track = '1';
    if (typeof data.volume !== 'number' || data.volume < 0 || data.volume > 1) data.volume = 0.4;
    if (typeof data.haptics !== 'boolean') data.haptics = true; // vibrations activées
    if (typeof data.morningSummary !== 'boolean') data.morningSummary = true; // résumé du matin activé
    return data;
  }

  function saveSettings(obj) {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(obj));
    } catch (e) { /* ignoré */ }
  }

  return {
    load: load, saveAll: saveAll, uid: uid,
    loadNotes: loadNotes, saveNotes: saveNotes,
    loadNotebook: loadNotebook, saveNotebook: saveNotebook,
    loadIntentions: loadIntentions, saveIntentions: saveIntentions,
    loadMoods: loadMoods, saveMoods: saveMoods,
    loadSettings: loadSettings, saveSettings: saveSettings
  };
})();
