package com.monagenda.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.media.MediaRecorder;
import android.speech.RecognizerIntent;
import android.util.Base64;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.PermissionState;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.io.File;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.util.ArrayList;

@CapacitorPlugin(name="AgendaVoice", permissions={@Permission(alias="microphone", strings={Manifest.permission.RECORD_AUDIO})})
public class AgendaVoice extends Plugin {
    private MediaRecorder recorder;
    private File audio;
    private boolean stopped;

    @PluginMethod public void dictate(PluginCall call) {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR");
        intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Dictez votre note");
        try { startActivityForResult(call, intent, "dictationResult"); }
        catch(Exception e) { call.reject("Dictée indisponible. Utilisez le clavier."); }
    }
    @ActivityCallback private void dictationResult(PluginCall call, ActivityResult result) {
        if(call == null) return;
        if(result.getResultCode()!=Activity.RESULT_OK || result.getData()==null){call.resolve();return;}
        ArrayList<String> words=result.getData().getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        JSObject ret=new JSObject();ret.put("text",words==null||words.isEmpty()?"":words.get(0));call.resolve(ret);
    }
    @PluginMethod public void startRecording(PluginCall call) {
        if(getPermissionState("microphone")!=PermissionState.GRANTED){requestPermissionForAlias("microphone",call,"microphoneResult");return;}
        begin(call);
    }
    @PermissionCallback private void microphoneResult(PluginCall call) {
        if(getPermissionState("microphone")==PermissionState.GRANTED)begin(call);else call.reject("Microphone refusé.");
    }
    private synchronized void begin(PluginCall call) {
        if(recorder!=null || audio!=null){call.reject("Enregistrement déjà en cours.");return;}
        try {
            stopped=false; audio=File.createTempFile("agenda-voice-", ".m4a",getContext().getCacheDir());
            recorder=new MediaRecorder(); recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4); recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioEncodingBitRate(64000);recorder.setAudioSamplingRate(22050);recorder.setOutputFile(audio.getAbsolutePath());
            recorder.setMaxDuration(60000);
            recorder.setOnInfoListener((r,what,extra)->{if(what==MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED){synchronized(this){if(recorder==r){try{r.stop();}catch(Exception ignored){}r.release();recorder=null;stopped=true;}}}});
            recorder.prepare();recorder.start();call.resolve();
        }catch(Exception e){discard();call.reject("Impossible de démarrer le microphone.");}
    }
    @PluginMethod public synchronized void stopRecording(PluginCall call) {
        if(audio==null){call.reject("Aucun enregistrement.");return;}
        try {
            if(recorder!=null){recorder.stop();recorder.release();recorder=null;stopped=true;}
            if(!stopped || audio.length()==0 || audio.length()>8*1024*1024)throw new Exception("Audio invalide");
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            try(FileInputStream in=new FileInputStream(audio)){byte[] b=new byte[8192];int count;while((count=in.read(b))!=-1)bytes.write(b,0,count);}
            JSObject ret=new JSObject();ret.put("data","data:audio/mp4;base64,"+Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP));call.resolve(ret);
        }catch(Exception e){call.reject("Message vocal trop court ou illisible.");}finally{discard();}
    }
    private synchronized void discard(){if(recorder!=null){try{recorder.release();}catch(Exception ignored){}recorder=null;}if(audio!=null){audio.delete();audio=null;}stopped=false;}
    @Override protected void handleOnDestroy(){discard();super.handleOnDestroy();}
}
