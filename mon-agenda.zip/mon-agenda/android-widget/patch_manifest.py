#!/usr/bin/env python3
# Injecte le <receiver> du widget dans le AndroidManifest.xml généré par Capacitor.
# Lancé depuis la racine du workspace par le workflow GitHub Actions.
import sys

PATH = "android/app/src/main/AndroidManifest.xml"

RECEIVER = """
        <receiver
            android:name=".MonAgendaWidget"
            android:exported="true"
            android:label="Mon Agenda">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data
                android:name="android.appwidget.provider"
                android:resource="@xml/mon_agenda_widget_info" />
        </receiver>
"""

try:
    src = open(PATH, encoding="utf-8").read()
except OSError as e:
    print("ERREUR: manifest introuvable: %s (%s)" % (PATH, e), file=sys.stderr)
    sys.exit(1)

if "MonAgendaWidget" in src:
    print("Manifest: receiver du widget deja present, rien a faire.")
elif "</application>" not in src:
    print("ERREUR: balise </application> introuvable dans le manifest.", file=sys.stderr)
    sys.exit(1)
else:
    src = src.replace("</application>", RECEIVER + "    </application>", 1)
    open(PATH, "w", encoding="utf-8").write(src)
    print("Manifest: receiver du widget ajoute.")
