#!/usr/bin/env python3
# Injecte le <receiver> du widget dans le AndroidManifest.xml généré par Capacitor.
# Lancé depuis la racine du workspace par le workflow GitHub Actions.
import sys

PATH = "android/app/src/main/AndroidManifest.xml"

RECEIVER = """
        <receiver
            android:name=".MonAgendaWidget"
            android:exported="true"
            android:label="Mon Agenda">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data
                android:name="android.appwidget.provider"
                android:resource="@xml/mon_agenda_widget_info" />
        </receiver>
"""

try:
    src = open(PATH, encoding="utf-8").read()
except OSError as e:
    print("ERREUR: manifest introuvable: %s (%s)" % (PATH, e), file=sys.stderr)
    sys.exit(1)

if "MonAgendaWidget" in src:
    print("Manifest: receiver du widget deja present, rien a faire.")
elif "</application>" not in src:
    print("ERREUR: balise </application> introuvable dans le manifest.", file=sys.stderr)
    sys.exit(1)
else:
    src = src.replace("</application>", RECEIVER + "    </application>", 1)
    open(PATH, "w", encoding="utf-8").write(src)
    print("Manifest: receiver du widget ajoute.")

# V3 : micro et plugin Capacitor local. Aucun changement au widget.
from pathlib import Path
import shutil
src = Path(PATH).read_text(encoding='utf-8')
if 'android.permission.RECORD_AUDIO' not in src:
    src = src.replace('</manifest>', '    <uses-permission android:name="android.permission.RECORD_AUDIO" />\n</manifest>', 1)
    Path(PATH).write_text(src, encoding='utf-8')
java = Path(PATH).parent / 'java/com/monagenda/app'
shutil.copyfile(Path(__file__).with_name('AgendaVoice.java'), java / 'AgendaVoice.java')
activity = java / 'MainActivity.java'
source = activity.read_text(encoding='utf-8')
if 'registerPlugin(AgendaVoice.class)' not in source:
    if 'class MainActivity extends BridgeActivity' not in source:
        raise RuntimeError('MainActivity Capacitor inattendue')
    # Capacitor 6: enregistrement avant super.onCreate afin que le bridge charge le plugin.
    activity.write_text('''package com.monagenda.app;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;
public class MainActivity extends BridgeActivity {
    @Override public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AgendaVoice.class);
        super.onCreate(savedInstanceState);
    }
}
''', encoding='utf-8')
