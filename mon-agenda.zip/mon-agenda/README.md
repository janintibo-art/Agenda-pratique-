# Mon Agenda — Rappel de tâches

Une petite application d'agenda **simple et soignée** pour noter ses tâches, ajouter une note, fixer une échéance et recevoir un **rappel** au bon moment. Elle contient deux vues : **Tâches** et un **Bloc-notes** avec une page par jour. Conçue comme une **PWA** (application web installable) : elle fonctionne dans le navigateur, s'installe sur le téléphone comme une vraie appli, marche **hors‑ligne**, et peut être transformée en **APK Android**.

> Vos données restent **uniquement sur votre appareil** (stockage local du navigateur). Rien n'est envoyé sur internet.

---

## ✨ Fonctionnalités

- **Ajout rapide** d'une tâche en une ligne, ou ajout détaillé (note, date, heure, priorité).
- **Tri automatique** des tâches : *En retard*, *Aujourd'hui*, *À venir*, *Sans échéance*, *Terminé*.
- **Rappels** par notification, à l'heure prévue **ou à l'avance** (5 min, 15 min, 30 min, 1 h, 1 jour avant).
- **Tâches récurrentes** : chaque jour, chaque semaine ou chaque mois (l'occurrence suivante se crée automatiquement à la validation).
- **Priorités** (basse / moyenne / haute).
- **Catégories en couleur** (Travail, Perso, Santé, Maison, Famille, Loisirs) à assigner aux tâches, avec **filtre par catégorie**.
- **Recherche** rapide dans les tâches (insensible aux accents et à la casse), depuis l'icône loupe de l'en-tête.
- **Filtres** : Toutes / À faire / Terminées.
- **Mise à jour en un geste** : quand une nouvelle version est déployée, un bandeau « Actualiser » s'affiche — plus besoin de fermer puis rouvrir l'application.
- **Vue Calendrier** : un mois complet avec pastilles sur les jours qui ont des tâches ou une note ; appuyez sur un jour pour voir ses tâches, ajouter une tâche à cette date ou ouvrir sa page de notes.
- **Bloc-notes** : une page de notes par jour, sauvegarde automatique, navigation entre les journées et historique de tous les jours notés.
- **Thème clair / sombre / système** (suit automatiquement le réglage du téléphone).
- **Fonds d'écran zen** : 24 ambiances apaisantes au choix (lotus, zen, nature, lumière) — désactivés par défaut, et le texte reste toujours lisible grâce à un voile adaptatif.
- **Identité « lotus »** : logo lotus doré, palette ivoire et or, soignée en clair comme en sombre.
- **Sauvegarde des données** : export et import au format JSON pour conserver ou transférer vos tâches et notes vers un autre appareil.
- **Installable** et **hors‑ligne** (PWA + service worker).
- Interface en **français**, responsive, accessible (clavier, contraste, mouvement réduit respecté).

---

## 🖼️ Aperçu

Placez vos captures d'écran dans `assets/screenshots/`, puis affichez‑les ici :

```md
![Écran principal](assets/screenshots/accueil.png)
![Ajout d'une tâche](assets/screenshots/ajout.png)
```

---

## ▶️ Lancer en local

**Le plus simple** : ouvrez `index.html` dans votre navigateur (aperçu de l'interface, ajout/lecture des tâches).

**Pour toutes les fonctions** (installation + notifications), il faut *servir* le dossier via un petit serveur local :

```bash
# avec Python (déjà installé sur la plupart des machines)
python3 -m http.server 8000
# puis ouvrez http://localhost:8000
```

> Astuce : l'extension **Live Server** de VS Code fait la même chose en un clic.

---

## 🌍 Mettre en ligne gratuitement (GitHub Pages)

**Conseil :** pour que l'APK fonctionne sans barre d'adresse (voir l'étape Digital
Asset Links plus bas), le plus simple est d'héberger l'app **à la racine** de votre
site GitHub. Pour cela, nommez le dépôt **`VOTRE-PSEUDO.github.io`** : l'app sera
alors servie à `https://VOTRE-PSEUDO.github.io/` (et non dans un sous-dossier).

1. Créez un dépôt nommé `VOTRE-PSEUDO.github.io` (remplacez par votre pseudo
   GitHub) et poussez‑y le **contenu** de ce dossier (les fichiers à la racine du
   dépôt, pas le dossier `mon-agenda/` lui‑même). Vous pouvez aussi tout
   glisser‑déposer via *Add file → Upload files*.
2. Dans le dépôt : **Settings → Pages**.
3. *Source* : branche `main`, dossier `/ (root)` → **Save**.
4. Au bout d'une minute, l'app est en ligne à `https://VOTRE-PSEUDO.github.io/`.

> Un dépôt classique (ex. `mon-agenda`) fonctionne aussi : l'app sera à
> `https://VOTRE-PSEUDO.github.io/mon-agenda/`. Les chemins du projet sont relatifs,
> donc tout marche en sous-dossier — sauf la vérification Digital Asset Links de
> l'APK, qui exige un fichier à la racine du domaine (plus simple avec le dépôt
> `VOTRE-PSEUDO.github.io`).

C'est cette adresse qui servira à générer l'APK.

---

## 📱 Générer l'APK Android

### Méthode 1 — PWABuilder (sans code, recommandée, via GitHub Pages)

1. Hébergez l'app (voir GitHub Pages ci‑dessus) et ouvrez l'URL dans Chrome pour
   vérifier qu'elle s'affiche bien.
2. Allez sur **https://www.pwabuilder.com** et collez l'URL de votre app.
   L'outil analyse le manifeste et le service worker (le projet est déjà conforme).
3. Cliquez sur **Package For Stores → Android**. Laissez les options par défaut
   (mode « Trusted Web Activity »), puis **Download**.
4. Le téléchargement contient l'**APK** (à installer pour tester), l'**AAB** (pour
   le Play Store), un fichier de **signature** (`signing.keystore` + mots de passe —
   gardez‑les précieusement pour vos futures mises à jour) et un fichier
   **`assetlinks.json`**.
5. **Important — vérification (sinon une barre d'adresse s'affiche en haut) :**
   ouvrez le `assetlinks.json` fourni et déposez‑le dans votre dépôt sous
   `.well-known/assetlinks.json`, à la **racine** du site
   (`https://VOTRE-PSEUDO.github.io/.well-known/assetlinks.json`). C'est ce qui lie
   l'APK à votre site et donne le plein écran sans barre d'adresse.
6. Installez l'APK sur le téléphone (autorisez « installer des applications
   inconnues » pour votre navigateur ou gestionnaire de fichiers).

> **Rappels :** en TWA, l'app tourne dans Chrome. Les rappels s'affichent quand
> l'app est ouverte ou récemment active, mais **pas de façon garantie quand elle est
> complètement fermée** (limite des PWA/TWA). Le **bandeau de mise à jour**, lui,
> fonctionne : republiez sur GitHub Pages et l'app proposera « Actualiser ».
> Pour des rappels fiables app fermée, voir la méthode Capacitor ci‑dessous.

### Méthode 2 — Capacitor (rappels fiables même application fermée)

Les notifications web ne se déclenchent de façon fiable que lorsque l'app est ouverte ou récemment active. Pour des **rappels planifiés même quand l'app est fermée**, on enveloppe l'app avec **Capacitor** et son plugin de notifications natives. Nécessite **Node.js** et **Android Studio**.

```bash
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/android @capacitor/local-notifications
npx cap init "Mon Agenda" "com.exemple.monagenda" --web-dir=.
npx cap add android
npx cap sync
npx cap open android   # ouvre Android Studio : Build → Build APK(s)
```

Ensuite, on remplace l'appel aux notifications web par le plugin `@capacitor/local-notifications` (planification à l'heure de l'échéance). Voir la doc : https://capacitorjs.com/docs/apis/local-notifications

---

## 🎨 Icônes, logo et fonds d'écran

- **Icône et logo** : générés à partir de votre lotus doré. Pour les remplacer,
  déposez vos fichiers dans `assets/icons/` en **gardant les mêmes noms** :
  `icon-192.png`, `icon-512.png`, `icon-maskable-512.png`, `apple-touch-icon.png`,
  `favicon-32.png` et `lotus-logo.png` (le logo de l'en-tête, idéalement sur fond
  transparent). Pour la version *maskable*, gardez le motif dans la zone centrale
  (~80 %) pour éviter qu'il soit rogné sur Android.
- **Fonds d'écran** : les 24 ambiances sont dans `assets/backgrounds/` (image
  pleine `bg-01.jpg` … `bg-24.jpg`) avec une miniature dans
  `assets/backgrounds/thumb/`. Pour en ajouter, déposez une image **et** sa
  miniature avec le numéro suivant (`bg-25.jpg`), puis passez `BG_COUNT` à 25 en
  haut de la section « Fond d'écran » de `js/app.js`.
- **Captures d'écran du README** : déposez‑les dans `assets/screenshots/`.

---

## 🗂️ Structure du projet

```
mon-agenda/
├── index.html              # Page et structure de l'application
├── manifest.json           # Métadonnées PWA (nom, icônes, couleurs)
├── service-worker.js       # Cache hors-ligne + clic sur notification
├── css/
│   └── styles.css          # Toute l'identité visuelle
├── js/
│   ├── storage.js          # Stockage local des tâches
│   ├── notifications.js    # Rappels / notifications
│   └── app.js              # Logique : affichage, ajout, édition, rappels
├── assets/
│   ├── icons/              # Icône, logo, favicon (lotus doré)
│   │   ├── icon-192.png
│   │   ├── icon-512.png
│   │   ├── icon-maskable-512.png
│   │   ├── apple-touch-icon.png
│   │   ├── favicon-32.png
│   │   └── lotus-logo.png
│   ├── backgrounds/        # 24 fonds zen (+ miniatures dans thumb/)
│   └── screenshots/        # Vos captures d'écran (pour le README)
├── README.md
├── LICENSE
└── .gitignore
```

---

## ⚠️ Bon à savoir sur les rappels

Tant que l'application est **ouverte ou récemment active**, les rappels
s'affichent à l'heure prévue. Pour des rappels **garantis lorsque le téléphone
est verrouillé et l'app complètement fermée**, utilisez la **méthode 2
(Capacitor)** : c'est le système Android lui‑même qui programme la notification.

---

## 📄 Licence

Distribué sous licence **MIT** — voir le fichier [`LICENSE`](LICENSE).
Vous êtes libre de l'utiliser, le modifier et le partager.
